-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2023 at 04:05 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adminpanel`
--

-- --------------------------------------------------------

--
-- Table structure for table `category_table`
--

CREATE TABLE `category_table` (
  `category_id` int(255) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_table`
--

INSERT INTO `category_table` (`category_id`, `category_name`) VALUES
(2, 'Batteries'),
(3, 'Inverter'),
(4, 'Generators'),
(5, 'Uncategorized');

-- --------------------------------------------------------

--
-- Table structure for table `client_testimonies`
--

CREATE TABLE `client_testimonies` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client_testimonies`
--

INSERT INTO `client_testimonies` (`id`, `username`, `email`, `comment`, `status`) VALUES
(1, 'cittu', 'cittu@gmail.com', ' wow i love your service keep it rolling  ', 1),
(2, 'judith', 'nuhu@yahoo.com', 'keep it up', 0),
(3, 'Mr Shittu', 'sh@gmail.com', '<p>what a nice service rendered, i will love to patronize you some other time</p>\r\n', 0),
(4, 'gabriel', 'yakubu@gmail.com', '<p><span style=\"font-size:16px\"><strong><span style=\"color:#2980b9\">this is great i love</span> this service rendere<span style=\"color:#e67e22\">d. thank you</span></strong></span></p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `address_1` varchar(255) NOT NULL,
  `address_2` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `phone_no`, `address_1`, `address_2`, `email`) VALUES
(1, '2348095156164', 'Business Address: Suite D7, Magodo Shopping Arcade Off Ayodele Fanioki Street Magodo Phase I Isheri Olowora Lagos', 'Abuja Office: Block A2, Suite 10 Commerce Plaza, Plot 1168, Durumi District, Area 1 FCT, Abuja', 'lafezaconsults@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `customer_table`
--

CREATE TABLE `customer_table` (
  `customer_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_table`
--

INSERT INTO `customer_table` (`customer_id`, `firstname`, `lastname`, `email`, `password`) VALUES
(1, 'jerry', 'miah', 'j@miah', 'jerry');

-- --------------------------------------------------------

--
-- Table structure for table `item_table`
--

CREATE TABLE `item_table` (
  `item_id` int(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_category` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `stock_level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `item_table`
--

INSERT INTO `item_table` (`item_id`, `item_name`, `item_category`, `brand_name`, `stock_level`) VALUES
(2, '1.5KVA-24VDC LUMINOUS INVERTER', '3', 'Luminous', 0),
(3, '12-200AH LUMINOUS BATTERY', '2', 'Luminous', 0),
(5, '12-200AH PRAGUE TABULAR GEL BATTERY', '2', 'Prag', 0),
(6, '12-150AH PRAGUE TABULAR GEL BATTERY', '2', 'prag', 0),
(7, '2KVA-24VDC PRAGUE INVERTER', '3', 'prag', 2),
(8, '4KVA PRAGUE INVERTER', '3', 'prag', 1),
(9, 'BATTERY', '2', 'Edicogroup', 2),
(10, 'GENERATOR CONVERSION KIT', '4', 'Kit', 1),
(11, 'INVERTER GENERATOR', '4', 'Gene', 2),
(12, 'KIPOR GENERATOR', '4', 'Kipor', 2),
(13, 'LUMINOUS BULB', '5', 'Luminous', 1);

-- --------------------------------------------------------

--
-- Table structure for table `management`
--

CREATE TABLE `management` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `management`
--

INSERT INTO `management` (`id`, `title`, `name`) VALUES
(1, '<p>Director</p>\r\n', '<p style=\"text-align:center\">Engr. Femi Yusuff IEng MICE MNSE MNIStructE<br />\r\nMr. Abass Idowu Yusuff</p>\r\n'),
(3, ' Deputy Director', '<p style=\"text-align:center\">Abdulzahir Yusuf</p>\r\n'),
(4, 'Managers', '<p style=\"text-align:center\">Engr. Mathew Idiahi MNSE<br />\r\nArc. Bayo Ibiyeye MNIA</p>\r\n'),
(5, 'Engineers', '<p style=\"text-align:center\">Obonomen Ehizele (Ass. Engineer)</p>\r\n'),
(6, 'Office and administrative personnel', '<p style=\"text-align:center\">Nasir Adebisi (Ass. Project Manager)</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `mission`
--

CREATE TABLE `mission` (
  `id` int(11) NOT NULL,
  `sub_title` varchar(300) NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mission`
--

INSERT INTO `mission` (`id`, `sub_title`, `description`) VALUES
(1, '<p style=\"text-align:center\"><span style=\"color:#000066\"><strong>a. Vision statement</strong></span></p>\r\n', '<p style=\"text-align:center\">At Lafeza Consultants we aspire to use innovative solutions to develop projects that are sustainable and durable for our clients. We also aspire to be a key player in the provision of affordable housing for Nigerians through innovative construction and design methods.</p'),
(2, '<p style=\"text-align:center\"><span style=\"color:#000066\"><strong>b. Mission statement</strong></span></p>\r\n', '<p style=\"text-align:center\">We are currently a medium sized company with projects in the Lagos and Abuja. We plan to continue our strategic growth by seeking projects that require our expertise in other parts of the country.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `our_background`
--

CREATE TABLE `our_background` (
  `background_id` int(11) NOT NULL,
  `sub_title` varchar(300) NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `our_background`
--

INSERT INTO `our_background` (`background_id`, `sub_title`, `description`) VALUES
(1, '<p style=\"text-align:center\"><span style=\"color:#000099\"><strong>a. Company History</strong></span><span style=\"color:#000066\"><strong>&nbsp;</strong></span></p>\r\n', '<p style=\"text-align:center\">Lafeza Consultants was established some years ago with the aim of providing unique solutions for our clients. We have been involved in the design and construction of various Challenging building and civil projects since the company&rsquo;s creation.</p>\r\n'),
(2, '<p style=\"text-align:center\"><strong><span style=\"color:#000099\">b. What We Do</span></strong>&nbsp;</p>\r\n', '<p style=\"text-align:center\">Lafeza Consultants is built around a strong dynamic team of Engineers, Architects and Artisans. We have expertise in the design and Construction of building, drainage and highway projects. We make our clients dream a reality by implementing advanced Project Management an');

-- --------------------------------------------------------

--
-- Table structure for table `our_info`
--

CREATE TABLE `our_info` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(300) NOT NULL,
  `description` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `our_info`
--

INSERT INTO `our_info` (`id`, `title`, `sub_title`, `description`) VALUES
(1, '<h2><strong><span style=\"color:#f1c40f\">Modern Solution&nbsp;</span>For All Your Design, Construction, Enginnering and <span style=\"color:#2ecc71\">Alternative Energy Solutions</span></strong></h2>\r\n', '<p>We are tested and proven to be the best at what we do.</p>\r\n', '<p>We deliver&nbsp;<strong>original and authentic engineering solutions&nbsp;</strong>with the aim of fulfilling clients requirement appropriately. Our objective is to provide solution that are functional and create an identity for the client that is unique based on the company&#39;s philosophy and mode of it&#39;s operation.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL,
  `sub_title` varchar(700) NOT NULL,
  `description` varchar(1200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `sub_title`, `description`) VALUES
(1, '<p style=\"text-align:center\"><span style=\"color:#000099\"><strong>a. Apart from several projects that we have handled for clients across the country, we are currently managing the following projects.</strong></span></p>\r\n', '<p style=\"text-align:center\">i. A Two storey residential building for Mr &amp; Mrs Adefuye in Lekki Phase II Ajah Lagos. The project includes the design and construction of drainage to channel water from the building compound to the external drainage. We have managed estate projects that require the renovation, construction of buildings, access roads and water supply network. Building construction is complete and the project is at installation of services stage.</p>\r\n\r\n<p style=\"text-align:center\">ii. two storey residential building for a private individual in Opic area, off Lagos/Ibadan Expressway. The building was designed on Pile foundation by Lafeza Consultants. Lafeza Consultants have been selected as part of the team to supervise the foundation construction</p>\r\n'),
(3, '<p style=\"text-align:center\"><span style=\"color:#000099\"><strong>b. Some of the complex projects we have managed include a Multi-story reinforced</strong></span></p>\r\n', '<p style=\"text-align:center\">concrete and steel framed residential structures (U.K), A Large steel frame team of Engineers, Architects and structure for Tesco Stores, built by covering the air space over a railway line with 2-pin precast concrete arches and back-filling its sides and top with suitable Engineering Techniques. material (U.K) and the renovation of an underground railway station (U.K).</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `firstname`, `lastname`, `email`, `password`, `usertype`) VALUES
(1, 'chimezie', 'ani', 'ani@gmail.com', '3dcb2bb4b46adbb8499af426e72dbd4c', 'admin'),
(2, 'judith', 'nuhu', 'nuhu@yahoo.com', 'a908ba2c8127aca53c44ab71193b96bd', 'user'),
(4, 'abdul', 'majeed', 'abdul@yahoo', '82027888c5bb8fc395411cb6804a066c', 'user'),
(5, 'cittu', 'cittu', 'cittu@gmail.com', '3abb39d80744d861b63f70d6441984cc', 'user'),
(6, 'sirjerry', 'jerry', 'jerry@yahoo.com', '6cd3b88726c38564d13cea99bab21c29', 'admin'),
(9, 'saheed', 'saheed', 'sa@yahoo.com', '12345', 'admin'),
(10, 'toafeek', 'toafeek', 'toafeek@gmail.com', '745ad0759fc89f36566cd26afed62db5', 'user'),
(11, 'kali', 'kali', 'kali@gmail.com', 'd6ca3fd0c3a3b462ff2b83436dda495e', 'user'),
(12, 'kator', 'kator', 'kator@yahoo.com', 'ab09cd3f32674d50a05b9e2d4860d686', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `sub_title` varchar(300) NOT NULL,
  `description` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `sub_title`, `description`) VALUES
(1, '<p style=\"text-align:center\"><span style=\"color:#000099\"><strong>a. Services</strong></span></p>\r\n', '<p style=\"text-align:center\">We design and construct building and Civil Projects; we also offer Project Management services.</p>\r\n'),
(2, '<p style=\"text-align:center\"><span style=\"color:#000099\"><strong>b. Business competitiveness</strong></span></p>\r\n', '<p style=\"text-align:center\">Our medium size makes us more competitive than other companies in our sector. We are quick at responding to the needs of our customers. We work with specialists focused on key aspects of engineering such as building and highway design and construction.</p>\r\n'),
(3, '<p style=\"text-align:center\"><span style=\"color:#000099\"><strong>c. Quality policies</strong></span></p>\r\n', '<p style=\"text-align:center\">We work to the British Standards, Eurocodes and available Nigerian Industrial Standards.&nbsp;</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `service_card`
--

CREATE TABLE `service_card` (
  `card_id` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_card`
--

INSERT INTO `service_card` (`card_id`, `image`, `title`, `description`) VALUES
(1, 'carousel_4.jpg', '<h5><strong>Quality policies</strong></h5>\r\n', '<p>Some quick example text to build on the card title and make up the bulk of the card&#39;s content'),
(3, 'carousel_12.jpg', '<h5><strong>Residential Construction</strong></h5>', '<p>Some quick example text to build on the card title and make up the bulk of the card&#39;s content'),
(4, 'carousel_8.jpg', '<h5><strong>Business competitiveness</strong></h5>', '<p>Some quick example text to build on the card title and make up the bulk of the card&#39;s content');

-- --------------------------------------------------------

--
-- Table structure for table `slide_table`
--

CREATE TABLE `slide_table` (
  `slide_id` int(11) NOT NULL,
  `slide_name` varchar(255) NOT NULL,
  `slide_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slide_table`
--

INSERT INTO `slide_table` (`slide_id`, `slide_name`, `slide_image`) VALUES
(1, 'inverter', 'carousel_8.jpg'),
(6, 'solar panel', 'carousel_2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `stock_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `cost` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stock_qty` varchar(11) NOT NULL,
  `visible` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stock_id`, `item_id`, `price`, `cost`, `image`, `stock_qty`, `visible`) VALUES
(4, 2, '678', '567', '1.5kva-24vdc-luminious-inverter1-1.jpg', '2', 0),
(5, 3, '35000.00', '28000.00', '12v-200ah-luminious-battery1-300x158-1.jpg', '1', 0),
(8, 5, '2000', '1300', '12v-200ah-prag-tubular-gel-battery1-300x300.jpg', '2', 0),
(9, 6, '250', '150', '12v-150ah-prag-tubular-gel-battery1-1-100x100-1.jpg', '1', 0),
(10, 7, '250', '200', '2kva-24VDC-prag-inverter1-1.jpg', '2', 0),
(11, 8, '200', '150', '4kva-prag-inverter-1-300x168.jpg', '1', 0),
(12, 9, '2000', '16500', 'IMG-20180404-WA0014-300x300.jpg', '2', 0),
(13, 10, '250', '200', 'IMG-20180407-WA0004-600x600-1-300x300.jpg', '1', 0),
(14, 11, '200', '150', 'IMG-20180420-WA0002-400x400-300x300.jpg', '2', 0),
(15, 12, '2000', '1300', 'IMG-20180404-WA0007-300x300-1.jpg', '2', 0),
(16, 13, '200', '150', 'IMG-20180407-WA0009-600x744-1-300x300.jpg', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vision`
--

CREATE TABLE `vision` (
  `id` int(11) NOT NULL,
  `sub_title` varchar(250) NOT NULL,
  `description` varchar(700) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vision`
--

INSERT INTO `vision` (`id`, `sub_title`, `description`) VALUES
(1, '<p style=\"text-align:center\"><span style=\"color:#0000cc\"><strong>a. Vision statement</strong></span></p>\r\n', '<p style=\"text-align:center\">At Lafeza Consultants we aspire to use innovative solutions to develop projects that are sustainable and durable for our clients. We also aspire to be a key player in the provision of affordable housing for Nigerians through innovative construction and design methods.</p>\r\n'),
(2, '<p style=\"text-align:center\"><span style=\"color:#0000cc\"><strong>b. Mission statement</strong></span></p>\r\n', '<p style=\"text-align:center\">We are currently a medium sized company with projects in the Lagos and Abuja. We plan to continue our strategic growth by seeking projects that require our expertise in other parts of the country.</p>\r\n'),
(3, '<p style=\"text-align:center\"><span style=\"color:#0000cc\"><strong>c. Values</strong></span></p>\r\n', '<p style=\"text-align:center\">Our core values are based on hardwork, transparency and honesty. We give our employees the opportunity to be the best they can be.</p>\r\n'),
(4, '<p style=\"text-align:center\"><span style=\"color:#0000cc\"><strong>d. Business goals &amp; objectives</strong></span></p>\r\n', '<p style=\"text-align:center\">Our target is to double our current income and staff strength in the next two years.</p>\r\n'),
(5, '<p style=\"text-align:center\"><span style=\"color:#0000cc\"><strong>e. Growth strategy</strong></span></p>\r\n', '<p style=\"text-align:center\">Our growth strategy will be achieved through organic growth and acquisition of small firms with values similar to ours.</p>\r\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category_table`
--
ALTER TABLE `category_table`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `client_testimonies`
--
ALTER TABLE `client_testimonies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_table`
--
ALTER TABLE `customer_table`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `item_table`
--
ALTER TABLE `item_table`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `management`
--
ALTER TABLE `management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mission`
--
ALTER TABLE `mission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `our_background`
--
ALTER TABLE `our_background`
  ADD PRIMARY KEY (`background_id`);

--
-- Indexes for table `our_info`
--
ALTER TABLE `our_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_card`
--
ALTER TABLE `service_card`
  ADD PRIMARY KEY (`card_id`);

--
-- Indexes for table `slide_table`
--
ALTER TABLE `slide_table`
  ADD PRIMARY KEY (`slide_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `vision`
--
ALTER TABLE `vision`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_table`
--
ALTER TABLE `category_table`
  MODIFY `category_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `client_testimonies`
--
ALTER TABLE `client_testimonies`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer_table`
--
ALTER TABLE `customer_table`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `item_table`
--
ALTER TABLE `item_table`
  MODIFY `item_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `management`
--
ALTER TABLE `management`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `mission`
--
ALTER TABLE `mission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `our_background`
--
ALTER TABLE `our_background`
  MODIFY `background_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `our_info`
--
ALTER TABLE `our_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `service_card`
--
ALTER TABLE `service_card`
  MODIFY `card_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `slide_table`
--
ALTER TABLE `slide_table`
  MODIFY `slide_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `stock_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `vision`
--
ALTER TABLE `vision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
