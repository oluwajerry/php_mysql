<footer class="bg-warning">

  <section class="section">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-3 col-lg-3">
          <img src="images/logo.jpg" alt="logo" width="50px">
          <p class="text-light"> <a href="#" class="text-decoration-none fa"> Lafezat Consults LTD.</a> <br>
              <span>Design, Construction, Engineering and Alternative Energy Solutions</span>
          </p>
          <div class="footer-social-media">
            <i class="fa fa-facebook ms-3"></i>
            <i class="fa fa-twitter ms-3"></i>
            <i class="fa fa-instagram ms-3"></i>
            <i class="fa fa-youtube ms-3"></i>
            <i class="fa fa-linkedin ms-3"></i>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 col-lg-3">
          <h4 class="text-white">Services</h4>
          <div class="underline bg-light mb-3"></div>
          <div class="footer-link"><a href="#" class="text fw-bolder text-decoration-none">Design</a></div>
          <div class="footer-link"><a href="#" class="text fw-bolder text-decoration-none">Construction</a></div>
          <div class="footer-link"><a href="#" class="text fw-bolder text-decoration-none">Engineering</a></div>
          <div class="footer-link"><a href="#" class="text fw-bolder text-decoration-none">Alternative Energy Solutions</a></div>
        </div>
        <div class="col-sm-12 col-md-3 col-lg-3">
          <h4 class="text-white">Quick links</h4>
          <div class="underline bg-light mb-3"></div>
          <div class="footer-link"><a href="index.php" class="text fw-bolder text-decoration-none">Home</a></div>
          <div class="footer-link"><a href="folio.php" class="text fw-bolder text-decoration-none">About Us</a></div>
          <div class="footer-link"><a href="shop.php" class="text fw-bolder text-decoration-none">Shop</a></div>
          <div class="footer-link"><a href="vision.php" class="text fw-bolder text-decoration-none">Vision and Mission Statement</a></div>
        </div>
        <?php
            
            // Connect to the database
            $connection = mysqli_connect("localhost", "root", "", "adminpanel");

            // Retrieve data from the table
            $query = "SELECT * FROM contact_us ORDER BY id";
            $result = mysqli_query($connection, $query);
            
            while ($row = mysqli_fetch_assoc($result)) 
                  {
          ?>
        <div class="col-sm-12 col-md-3 col-lg-3">
          <h4 class="text-white">Contact US</h4>
          <div class="underline bg-light mb-3"></div>
          <p class="f-14 fw-bold">
            <i class="fa fa-phone"></i>
            <a href="tel:+2348095156164" class="text">Tel: +<?php echo $row['phone_no']; ?></a>  
          </p>
          <p class="f-14 fw-bold">
            <i class="fa fa-map-marker"></i> 
            <?php echo $row['address_1']; ?>
          </p>
          <p class="f-14 fw-bold"> 
            <i class="fa fa-envelope"></i>
             <a href="mailto:lafezaconsults@yahoo.com" class="text">Email: <?php echo $row['email']; ?></a>  
          </p>
          <p class="f-14 fw-bold">
            <i class="fa fa-map-marker"></i> 
            <?php echo $row['address_2']; ?>
          </p>
        </div>
        <?php 
                  } 
        ?>
      </div>
    </div>
  </section>
  <section class="py-3 bg">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 text-center">
          <p class="text-warning f-14">
          Lafeza Consults LTD &copy; Copyrights <?php echo date('Y')?>. All Rights Reserved
          </p>
        </div>
      </div>
    </div>
  </section>

</footer>


  </body>
</html>