<script src="js/boostrap.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script>
      $('.testimonials').owlCarousel({
          loop:true,
          margin:10,
          nav:false,
          dots:true,
          responsive:{
              0:{
                  items:1
              },
              600:{
                  items:1
              },
              1000:{
                  items:1
              }
          }
        })
    </script>

    <script>
        var gt=0;
        var iprice = document.getElementsByClassName('iprice');
        var iquantity = document.getElementsByClassName('iquantity');
        var itotal = document.getElementsByClassName('itotal');
        var gtotal = document.getElementById('gtotal');
        var ggtotal = document.getElementById('ggtotal');
       
       

        function subTotal(){
            gt=0;
            for ( i = 0; i < iprice.length; i++) {
                itotal[i].innerText=(iprice[i].value) * (iquantity[i].value);
                
                //ty=itotal[i]; 

                gt = gt + (iprice[i].value) * (iquantity[i].value);

                
            }
            gtotal.innerText=gt;
            ggtotal.innerText = gt;
           


            var store = gt;
            sessionStorage.setItem("store", store);


            //use to get stored item from the browser
           //var storedValue = sessionStorage.getItem("store");

        }
        subTotal();

    </script>

    <script>
        
         var storedValue = sessionStorage.getItem("store");
        var grandtotal = document.getElementById('tol');
        
    
        grandtotal.innerHTML ="<i>" + storedValue + "</i>"; 
        amount.value = storedValue;
    </script>
    <script>
        var storedValue = sessionStorage.getItem("store");
        var amount =  document.getElementById('amount');
        amount.value = storedValue;
    </script>


<script src="https://js.paystack.co/v1/inline.js"></script> 

<script>
const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: 'pk_test_ffefba1eba5f614aca13d1f98a4b1db31becb5a0', // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: document.getElementById("amount").value * 100,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
        window.location = "cart.php";
      alert('Transaction Cancelled.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
    }
  });

  handler.openIframe();
}
</script>

   <!--  <script>
        $(document).ready(function() {
            $('#tick-button').click(function() {
                $.ajax({
                    url: 'shop.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        if (response.isClicked) {
                            // update button with tick mark
                            $('#tick-button').html('<i class="fas fa-check"></i> Tick');
                        }
                    }
                });
            });
        });
    </script>
<!-- JavaScript 
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> -->
