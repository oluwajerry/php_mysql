
                                                        <!-- navbar -->
<header class="sticky-top">
    <nav class="navbar navbar-expand-lg navbar-dark bg">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="other_Images/logo.jpg" alt="logo" width="60px">
            <p class="text-light fw-bolder text-decoration-none">Lafezat Consults LTD.</p>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link text-warning active " aria-current="page" href="index.php">HOME</a>
            </li>
          <!--  <li class="nav-item">
              <a class="nav-link text-warning" href="include/history.php">HISTORY</a>
            </li> -->
            <li class="nav-item dropdown">
              <a class="nav-link text-warning dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">ABOUT US</a>
              <ul class="dropdown-menu bg-dark">
                <li><a class="dropdown-item text-warning fw-bolder" href="folio.php">PORTFOLIO</a></li>
                <li><hr class="dropdown-divider"></li>
                <!-- <li><a class="dropdown-item text-warning fw-bolder" href="#">MANAGEMENT AND OWNERSHIP</a></li> -->
              </ul>
            </li>
            <li class="nav-item">
              <a class="nav-link text-warning" href="vision.php">VISION AND MISSION STATEMENT</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-warning" href="shop.php">SHOP</a>
            </li>
            <!-- <li class="nav-item">
              <a class="nav-link text-warning" href="#">RECENT PROJECT</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-warning" href="#">TESTIMONIES</a>
            </li> -->
          </ul>
        </div>
      </div>
    </nav>
</header>
                                            <!-- cart, search and product section -->
    <section class="bg-light p-5">
      <div class="container">
        <div class="row">
          <div class="col-md-3 my-auto d-block d-sm-block pb-2">
            <button style="width:100%;" type="button" data-bs-toggle="dropdown" aria-expanded="false" class="btn btn-warning but" >
                <img src="other_Images/menu.png" alt="menu" width="30px" class="" > <span class="fw-bolder">My Products</span>
              </button><br>
              <ul class="dropdown-menu bg-dark text-light text-center">
                <li><a href="#" class="text-light fw-bolder text-decoration-none">Batteries</a></li><hr class="color-white">
                <li><a href="#" class="text-light fw-bolder text-decoration-none">Generators</a></li><hr class="color-white">
                <li><a href="#" class="text-light fw-bolder text-decoration-none">Inverters</a></li><hr class="color-white">
                <li><a href="#" class="text-light fw-bolder text-decoration-none">Uncategorized</a></li>
              </ul>
          </div>
          <div class="col-md-5 my-auto d-block d-sm-block pb-2">
            <form role="search">
              <div class="input-group">
                <input type="search" placeholder="Search your product" class="form-control" />
                <button class="btn bg-warning" type="submit">
                  <i class="fa fa-search"></i>
                </button>
              </div>
            </form>
          </div>
          <div class="col-md-4 my-auto d-block d-sm-block ">
            <ul class="d-flex list-unstyled flex">
              <li class="item">
                <?php
                  if (isset($_SESSION['user_name'])) 
                  {
                  ?>
                  <a class="item-link text-decoration-none" href="#">
                    <h4 class="acc"><i class="fa fa-user"></i> <?php echo "Welcome". " "."<span class=\"text-danger fw-bolder\"> ". $_SESSION['user_name']."</span>"; ?></h4>
                  </a>
                  <?php
                    }
                    else 
                    {
                    ?>
                  <a class="item-link text-decoration-none" href="#">
                    <h5 class="acc"><i class="fa fa-user"></i> Account</h5>
                  </a>  
                    <?php
                    }
                ?>
              </li>
              <li class="item">
                <a class="item-link text-decoration-none" href="cart.php">
                  <h5 class="acc"><i class="fa fa-shopping-cart"></i> Cart
                      <?php
                        if (isset($_SESSION['cart'])) 
                        {
                          $count=count($_SESSION['cart']);
                          echo"<span id=\"cart_count\" class=\"text-warning fw-bolder \">($count)</span>";
                        }
                        else 
                        {
                          echo"<span id=\"cart_count\" class=\"text-warning fw-bolder \">(0)</span>";
                        } 
                      ?>
                  </h5>
                
                </a>
              </li>
            </ul>
          </div>

        </div>
                
      </div>
    </section>