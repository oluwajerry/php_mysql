<?php 
    include('include/session.php'); 
    include('include/header.php'); 
    include('include/navbar.php');
?>

    <section class="section">
      <div class="container">
        <div class="row">
          <?php
              
              // Connect to the database
              $connection = mysqli_connect("localhost", "root", "", "adminpanel");

              // Retrieve data from the table
              $query = "SELECT sub_title, description FROM portfolio ORDER BY id";
              $result = mysqli_query($connection, $query);

              // Loop through the result set and print the data
              $subtitle = '';

            ?>
          <div class="col-sm-12 col-md-12 col-lg-12">
            <h2 class="section-title text-center"><span class="text-warning">PORT</span>FOLIO</h2>
            <div class="underline bg-warning me-auto ms-auto mb-2"></div>
            <p class="section-subtitle text-center">
              <?php
                    while ($row = mysqli_fetch_assoc($result)) 
                    {
                      if ($subtitle !== $row['sub_title']) 
                      {
                        $subtitle = $row['sub_title'];
                  ?>
                  <?php echo $subtitle; 
                      }
                  ?> <br>
                  <?php echo $row['description']; 
                    } 
              ?>
            </p>
          </div>
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="row">
          <?php
              
              // Connect to the database
              $connection = mysqli_connect("localhost", "root", "", "adminpanel");

              // Retrieve data from the table
              $query = "SELECT title, name FROM management ORDER BY id";
              $result = mysqli_query($connection, $query);

              // Loop through the result set and print the data
              $title = '';

            ?>
          <div class="col-sm-12 col-md-12 col-lg-12">
            <h2 class="section-title text-center"><span class="text-warning">Management</span> And Ownership</h2>
            <div class="underline bg-warning me-auto ms-auto mb-2"></div>
            <p class="section-subtitle text-center">
            <?php
                  while ($row = mysqli_fetch_assoc($result)) 
                  {
                    if ($title !== $row['title']) 
                    {
                      $title = $row['title'];
                ?>
                <?php echo "<center class='text fw-bolder' >". $title ."</center>"; 
                    }
                ?> <br>
                <?php echo $row['name']; 
                  } 
                ?>
            </p>
          </div>
        </div>
      </div>
    </section>


<?php 
    include('include/script.php'); 
    include('include/footer.php');
?>
