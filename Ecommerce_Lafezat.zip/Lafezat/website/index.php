<?php 
    include('include/session.php');
    include('include/header.php'); 
    include('include/navbar.php');
?>
                                                    <!-- carousel -->
<!-- <div class="container body">
  <div class="col-sm-12 col-md-10 col-lg-10"> -->
<div class="container body">
  <div class="col-sm-12 col-md-12 col-lg-12">
    <section>
      <div class="container" >
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12" > <!-- it was col-md-9 && col-lg-9 before i commented the video and latest news part    -->
            <section class="1">
              <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                <?php
                      $connection = mysqli_connect("localhost","root","","adminpanel");
                      $query = "SELECT slide_image FROM slide_table LIMIT 3";
                      $query_run = mysqli_query($connection, $query);

                    
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            {
                              $image = $row['slide_image'];
                              ?>
                  <div class="carousel-item active">
                      <img src="<?php echo 'admin/slide_upload/'.$image ?>" class="d-block w-100" alt="carousel">
                  </div>
                  <?php
                            }
                    ?>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </button>
              </div>
            </section>
                                                <!-- Brief description   -->
            <section class="section text-center" style="background-color: #eee;" >
              <div class="container">
                <div class="row">
                  <?php
                        $connection = mysqli_connect("localhost","root","","adminpanel");
                        $query = "SELECT * FROM our_info";
                        $query_run = mysqli_query($connection, $query);

                        $row = mysqli_fetch_assoc($query_run); 
                  ?>
                  <div class="col-sm-12 col-md-12 col-lg-12 "> <!-- it was col-md-9 && col-lg-9 and ms-5 before i commented the video and latest news part    -->
                    <h2 class="section-title text-center"><?php echo $row['title']; ?></h2>
                    <div class="underline bg-warning me-auto ms-auto mb-2"></div>
                    <p class="section-subtitle text-center ">
                        <?php echo $row['sub_title']; ?>
                    </p>
                  </div>

                  <div class="col-sm-12 col-md-12 col-lg-12 "> <!-- it was col-md-9 && col-lg-9 and ms-5 before i commented the video and latest news part    -->
                    <p class="text-center">
                        <?php echo $row['description']; ?> 
                    </p>
                  </div>
                </div>
              </div>
            </section>
                                                         
          </div>
                                                        <!-- video content -->
          <!-- <div class="col-sm-12 col-md-2 col-md-2 offset-1 " >
            <div class="video border border-5 p-2">
              <div id="media_video-2" class="widget widget_media_video"><h3 class="widget-title">Generator Powered By Cooking Gas</h3>
                <div style="width:100%;" class="wp-video">
                  <span class="mejs-offscreen">Video Player</span>
                  <div id="mep_0" class="mejs-container wp-video-shortcode mejs-video" tabindex="0" role="application" aria-label="Video Player" style="width: 205px; height: 115.312px; min-width: 182px;">
                    <div class="mejs-inner">
                      <div class="mejs-mediaelement">
                        <mediaelementwrapper id="video-28-1">
                          <div id="video-28-1-iframe-overlay" class="mejs-iframe-overlay"></div>
                          <iframe id="video-28-1_youtube_iframe" frameborder="0" allowfullscreen="1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" title="Video demonstration of generator powered by cooking gas" 
                            src="images/video.mp4" width="100" height="120.3125">
                          </iframe>
                          <video class="wp-video-shortcode" id="video-28-1_from_mejs" preload="metadata" src="https://youtu.be/6RQkXp6oGi8?_=1" style="width: 100%; height: 100%; display: none;">
                            <source type="video/youtube" src="https://youtu.be/6RQkXp6oGi8?_=1"><a href="https://youtu.be/6RQkXp6oGi8">https://youtu.be/6RQkXp6oGi8</a>
                          </video>
                        </mediaelementwrapper>
                      </div>
                      <div class="mejs-layers">
                        <div class="mejs-poster mejs-layer" style="display: none; width: 100%; height: 100%;"></div>
                        <div class="mejs-overlay mejs-layer" style="width: 100%; height: 100%; display: none;">
                          <div class="mejs-overlay-loading">
                            <span class="mejs-overlay-loading-bg-img"></span>
                          </div>
                        </div>
                        <div class="mejs-overlay mejs-layer" style="display: none; width: 100%; height: 100%;">
                          <div class="mejs-overlay-error"></div>
                        </div>
                        <div class="mejs-overlay mejs-layer mejs-overlay-play" style="display: none; width: 100%; height: 100%;">
                          <div class="mejs-overlay-button" role="button" tabindex="0" aria-label="Play" aria-pressed="false"></div>
                        </div>
                      </div>
                      <div class="mejs-controls mejs-offscreen" style="opacity: 0;">
                        <div class="mejs-button mejs-playpause-button mejs-pause">
                          <button type="button" aria-controls="mep_0" title="Pause" aria-label="Pause" tabindex="0"></button>
                        </div>
                        <div class="mejs-time mejs-currenttime-container" role="timer" aria-live="off"><span class="mejs-currenttime">00:32</span></div>
                          <div class="mejs-time-rail">
                            <span class="mejs-time-total mejs-time-slider" role="slider" tabindex="0"><span class="mejs-time-buffering" style="display: none;"></span>
                              <span class="mejs-time-loaded"></span><span class="mejs-time-current" style="transform: scaleX(0.933419);"></span><span class="mejs-time-hovered no-hover"></span>
                              <span class="mejs-time-handle" style="transform: translateX(19px);"><span class="mejs-time-handle-content"></span></span>
                              <span class="mejs-time-float"><span class="mejs-time-float-current">00:00</span><span class="mejs-time-float-corner"></span></span>
                            </span>
                        </div>
                        <div class="mejs-time mejs-duration-container">
                          <span class="mejs-duration">00:53</span>
                        </div>
                        <div class="mejs-button mejs-volume-button mejs-mute">
                          <button type="button" aria-controls="mep_0" title="Mute" aria-label="Mute" tabindex="0"></button>
                          <a href="javascript:void(0);" class="mejs-volume-slider" aria-label="Volume Slider" aria-valuemin="0" aria-valuemax="100" role="slider" aria-orientation="vertical" aria-valuenow="80" aria-valuetext="80%">
                            <span class="mejs-offscreen">Use Up/Down Arrow keys to increase or decrease volume.</span>
                            <div class="mejs-volume-total">
                              <div class="mejs-volume-current" style="bottom: 0px; height: 80%;"></div>
                              <div class="mejs-volume-handle" style="bottom: 80%; margin-bottom: -3px;">
                              </div>
                            </div>
                          </a>
                        </div>
                        <div class="mejs-button mejs-fullscreen-button">
                          <button type="button" aria-controls="mep_0" title="Fullscreen" aria-label="Fullscreen" tabindex="0"></button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div><br><br><br><br><br><br><br>
            <div class="tariff border border-5 w-100 p-2">
              <div id="recent-posts-2" class="widget widget_recent_entries">
                  <h3 class="widget-title">Latest News</h3>
                  <ul class="list-unstyled">
                    <li>
                      <a href="https://lafezaconsults.com.ng/2021/01/28/electricity-tariffs/" class="text-decoration-none ">Electricity Tariffs</a>
                    </li>
                  </ul>
              </div>
            </div>
          </div> -->
        </div>
      </div>
    </section>   
  </div>
</div>
                                                    <!-- BACKGROUND  -->
    <section class="section">
      <div class="container">
        <div class="row">
          <?php
          
              // Connect to the database
              $connection = mysqli_connect("localhost", "root", "", "adminpanel");

              // Retrieve data from the table
              $query = "SELECT sub_title, description FROM our_background ORDER BY background_id";
              $result = mysqli_query($connection, $query);

              // Loop through the result set and print the data
              $subtitle = '';

          ?>
          <div class="col-sm-12 col-md-12 col-lg-12">
            <h2 class="section-title text-center"><span class="text-warning">Our</span> Background</h2>
            <div class="underline bg-warning me-auto ms-auto mb-2"></div>
            <p class="section-subtitle text-center text">
              <?php
                while ($row = mysqli_fetch_assoc($result)) 
                {
                  if ($subtitle !== $row['sub_title']) 
                  {
                    $subtitle = $row['sub_title'];
              ?>
              <?php echo $subtitle; 
                  }
              ?> <br>
              <?php echo $row['description']; 
                } 
              ?>
            </p>
          </div>
        </div>
      </div>
    </section>
                                                <!-- Our Services -->
    <section class="section bg-f2f2f2">
      <div class="container">
        <div class="row">
          <?php
            
            // Connect to the database
            $connection = mysqli_connect("localhost", "root", "", "adminpanel");

            // Retrieve data from the table
            $query = "SELECT sub_title, description FROM service ORDER BY id";
            $result = mysqli_query($connection, $query);

            // Loop through the result set and print the data
            $subtitle = '';

          ?>
          <div class="col-sm-12 col-md-12 col-lg-12">
            <h2 class="section-title text-center"><span class="text-warning">Our</span> Services</h2>
             <div class="underline bg-warning me-auto ms-auto mb-2"></div>
            <p class="section-subtitle text-center">
              <?php
                  while ($row = mysqli_fetch_assoc($result)) 
                  {
                    if ($subtitle !== $row['sub_title']) 
                    {
                      $subtitle = $row['sub_title'];
                ?>
                <?php echo $subtitle; 
                    }
                ?> <br>
                <?php echo $row['description']; 
                  } 
                ?>
            </p>
          </div>
        </div>
        <div class="row">
          <?php
            
            // Connect to the database
            $connection = mysqli_connect("localhost", "root", "", "adminpanel");

            // Retrieve data from the table
            $query = "SELECT image,title,SUBSTRING(description, 1, 54) as description FROM service_card ORDER BY card_id LIMIT 3";
            $result = mysqli_query($connection, $query);
            
            while ($row = mysqli_fetch_assoc($result)) 
                  {
          ?>
          <div class="col-md-4 mt-3">
            <div class="card">
              <img src="admin/card_upload/<?php echo $row['image']; ?>" class="card-img-top" alt="images">
              <div class="card-body text-center">
                <h5 class="card-title"><?php echo $row['title']; ?></h5>
                <div class="underline bg-warning me-auto ms-auto mb-3"></div> 
                <p class="card-text"><?php echo $row['description']; ?></p>
                <a href="#" class="ReadMore fw-bolder">read more</a>
              </div>
            </div>
          </div>
          <?php 
                  } 
          ?>
        </div>
      </div>
    </section>

    <section class="bg-f2f2f2">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-12 col-lg-12">
            <h2 class="section-title "><span class="text-warning">Client</span> Testimonials</h2>
            <div class="underline bg-warning  mb-2"></div>
            <p class="section-subtitle ">
              Seeing is believing!!  what they testified about our  services.
            </p>
          </div>
        </div>
        <div class="row">
          <div class="d-sm-block col-md-8 col-lg-8">
            <div class="card">
              <div class="card-body text-center">
                <div class="owl-carousel testimonials owl-theme">
                  <div class="item">
                    <div class="testi-image">
                      <img src="images/test1.png" class="me-auto ms-auto" alt="image">
                    </div>
                    <div class="testi-content">
                      <?php
                        $connection = mysqli_connect("localhost","root","","adminpanel");
                        $query = "SELECT username, comment
                                  FROM client_testimonies
                                  WHERE status = 1
                                  ORDER BY username ASC
                                  LIMIT 1";
                        $query_run = mysqli_query($connection, $query);

                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            {
                        ?>
                      <p class="fa"> <span class="text-dark">"</span class="text-dark">
                        <?php echo $row['comment']; ?> <span class="text-dark">"</span class="text-dark">
                      </p>
                      <h3 class="text-warning"><?php echo $row['username']; ?></h3>
                      <?php
                            }
                        }
                      ?>
                    </div>
                  </div>
                  <div class="item">
                    <div class="testi-image">
                      <img src="images/test1.png" class="me-auto ms-auto" alt="image">
                    </div>
                    <div class="testi-content">
                      <?php
                        $connection = mysqli_connect("localhost","root","","adminpanel");
                        $query = "SELECT username, comment
                                  FROM client_testimonies
                                  WHERE status = 1
                                  ORDER BY username DESC
                                  LIMIT 1";
                        $query_run = mysqli_query($connection, $query);

                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            { 
                        ?>
                      <p class="fa"> <span class="text-dark">"</span class="text-dark">
                        <?php echo $row['comment']; ?> <span class="text-dark">"</span class="text-dark">
                      </p>
                      <h3 class="text-warning"><?php echo $row['username']; ?></h3>
                      <?php
                            }
                        }
                      ?>
                    </div>
                  </div>
                  <div class="item">
                    <div class="testi-image">
                      <img src="images/test1.png" class="me-auto ms-auto" alt="image">
                    </div>
                    <div class="testi-content">
                      <?php
                        $connection = mysqli_connect("localhost","root","","adminpanel");
                        $query = "SELECT username, comment
                                  FROM client_testimonies
                                  WHERE status = 1
                                  ORDER BY id DESC
                                  LIMIT 1";
                        $query_run = mysqli_query($connection, $query);

                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            { 
                        ?>
                      <p class="fa"> <span class="text-dark">"</span class="text-dark">
                        <?php echo $row['comment']; ?> <span class="text-dark">"</span class="text-dark">
                      </p>
                      <h3 class="text-warning"><?php echo $row['username']; ?></h3>
                      <?php
                            }
                        }
                      ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="d-sm-block col-md-4 col-lg-4">
          <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] !='') 
            {
                echo '<h2 class="text-warning"> '.$_SESSION['success'].' </h2>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] !='') 
            {
                echo '<h2 class="text-danger"> '.$_SESSION['status'].' </h2>';
                unset($_SESSION['status']);
            }
            
            ?>

            <span class="text-center fa fw-bolder">leave your comment here</span>
            <form action="code2.php" method="POST">
              <div class="form-group">
                    <label for="">name</label>
                    <input type="text" name="username" class="form-control" placeholder="Enter your name">
                </div>
                <div class="form-group">
                    <label for="">email</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter email">
                </div><br>
                <div class="form-group">
                    <textarea name="text" cols="30" rows="3" class="form-control"  placeholder="comment here"></textarea>
                </div><br>
                <div class="form-group">
                    <button type="submit" name="testimony" class="btn btn-dark text-light">SUBMIT</button>
                </div><br>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  <!-- </div>
</div> -->


<?php 
  include('include/script.php'); 
  include('include/footer.php');
?>