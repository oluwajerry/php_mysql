<?php 
    include('include/session.php');
    include('include/header.php'); 
    include('include/navbar.php');
?>

    <div class="container-fluid">
        <form action="checkout.php" method="POST" class="cart-items">
            <div class="row px-5">
                <div class="col-sm-12 col-md-7 col-lg-7">
                    <div class="shopping-cart">
                        <h3>My Cart</h3>
                        <hr>
                        <?php
                            if (isset($_SESSION['cart'])) 
                            {
                                $item_id=array_column($_SESSION['cart'], 'item_id'); 
                                      
                                $connection = mysqli_connect("localhost", "root", "","adminpanel");
          
                                $sql = "SELECT item_table.item_name,stock.image,item_table.brand_name,stock.price,item_table.item_id 
                                FROM item_table
                                INNER JOIN stock
                                ON item_table.item_id = stock.item_id
                                GROUP BY item_table.item_id";

                                $result=mysqli_query($connection, $sql);
                                while ( $row =mysqli_fetch_assoc($result) )
                                {
                                    foreach ($item_id as $id) 
                                    {
                                        if ($row['item_id']==$id) 
                                        {
                        ?>
                                            <div class="border rounded">
                                                <div class="row bg-white">
                                                    <div class="col-md-3 pl-0">
                                                        <img src="admin/upload/<?php echo $row['image']; ?>" alt="bluetooth" class="img-fluid">
                                                    </div>
                                                    <div class="col-md-5">
                                                        <h5 class="pt-2"><?php echo $row['item_name']; ?></h5>
                                                        <small class="text-secondary">seller: dailytuition</small>
                                                        <h5 class="pt-2"><?php echo '₦'. $row['price']; ?><input type="hidden" class="iprice" value="<?php echo $row['price'];?>"></h5>
                                                        <button type="submit" class="btn btn-warning">save for later</button>
                                                        <button type="submit" class="btn btn-danger mx-2 " name="remove"><a href="cart.php?del_ID=<?php echo $row['item_id'];?>" class="text-light text-decoration-none ">Remove</a></button>
                                                        <?php
                                                        
                                                        if(isset($_GET['del_ID']))
                                                        {
                                                            // getting the id from the url;
                                                            $id = $_GET['del_ID'];
                                                            $productRemoved = false;
                                                            foreach ($_SESSION['cart'] as $key => $value) 
                                                            {
                                                                if ($value["item_id"]==$_GET['del_ID']) 
                                                                {
                                                                   unset($_SESSION['cart'][$key]);
                                                                    //echo "<h3 class=\"text-danger\"> product has been Removed successfully...!!! </h3>";
                                                                     echo"<script>alert('product has been Removed...!!!')</script>";
                                                                    echo"<script>window.location='cart.php'</script>"; 
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                    <div class="col-sm-6 col-md-3 col-lg-3 py-5">
                                                        <p class="fw-bold">Qty</p>        
                                                        <input type="hidden" name="cart_id[]" value="<?php echo $row['item_id']; ?>">
                                                        <input type="number" min='1' value="1" onchange="subTotal()" oninput="subTotal()" name="Qty[]" class="form-control w-50 d-inline iquantity">
                                                        <!-- <button type="button" class="btn bg-light border rounded-circle"><i class="fas fa-plus"></i></button> -->
                                                    </div>
                                                    <div class="col-sm-3 col-md-1 col-lg-1 py-5">
                                                        <table>
                                                            <thead>
                                                                <th>TotalPrice</th>
                                                            </thead>
                                                            <tbody class="text-center">
                                                                <tr>
                                                                    <td class="itotal"></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                        <?php
                                    
                                        }
                                    }
                                }
                            }
                            else 
                            {
                                echo"<h5>Cart is Empty</h5>";
                            }
                                            
                        ?>
                    </div>
                </div>
                <div class="col-sm-12 col-md-4 col-lg-4 offset-md-1 border rounded mt-5 bg-white h-25">
                        <div class="pt-4">
                            <h5>PRICE DETAILS</h5>
                            <hr>
                            <div class="row price-details">
                                <div class="col-sm-6 col-md-6 col-lg-6">
                                    <?php
                                    if (isset($_SESSION['cart'])) {
                                        $count=count($_SESSION['cart']);
                                        //echo"<h6>Price($count items)</h6>";
                                        echo"<h5 class=\"text-danger fw-bolder\">Grand TotalPrice</h5>";
                                    }
                                    else {
                                        echo"<h5>Grand TotalPrice(0 items)</h5>";
                                    }
                                    ?>
                                    <h5>Delivery Charges</h5>
                                    <hr>
                                    <h5>Amount Payable</h5>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-6">
                                    <!-- <h6 class="itotal"></h6> -->
                                    <!-- <h6>₦<?php //echo $grandTotal ?></h6> -->
                                    <h4 id="gtotal"></h4>
                                    <h6 class="text-success">FREE</h6>
                                    <hr>
                                    <!-- <h6>₦<?php //echo $grandTotal ?></h6> -->
                                    <h4 id="ggtotal"></h4>
                                </div>
                            </div>
                        </div>
                        <input type="submit" value="CHECKOUT" name="button" class="btn btn-warning w-100 fw-bolder ">
                </div>
            </div>                    
                    
        </form>
    </div> <br><br><br>


<?php 
    include('include/script.php'); 
    include('include/footer.php');
?>