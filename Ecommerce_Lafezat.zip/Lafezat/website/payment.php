<?php
include('include/session.php');
include('function.php');
include('include/header.php');     
include('include/navbar.php');

$_SESSION['firstname'] = $_POST['firstname'];

$_SESSION['lastname'] = $_POST['lastname'];

$_SESSION['email'] = $_POST['email'];

$_SESSION['amount'] = $_POST['amount'];

$_SESSION['phone'] = $_POST['phone'];

$_SESSION['zip'] = $_POST['pincode'];
  
$_SESSION['delivery_address'] = $_POST['address'];
  
$_SESSION['region'] = $_POST['city']; 

?>


        <div class="container">
            <div class="combine">
                <div class="row">
                    <div class="col-md-7">
                        <div class="paystack_and_privacy">
                            <img src="other_images/paystack.png" alt="paystack">
                            <div>
                                <em>Your personal data will be used to process your order, support your experience 
                                    throughout this website, and for other purposes described in our <span class="fw-bolder">privacy policy</span>
                                </em> 
                            </div>
                        </div><br><br>
                        <div class="order">
                            <h3 class="text">PAY FOR ORDER</h3><br>
                            <table class="table table-warning table-striped">
                                <thead >
                                    <th style="font-weight: normal;">Date</th>
                                    <th style="font-weight: normal;">Total Amount</th>
                                    <th style="font-weight: normal;">Payment Method</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="fw-bolder"> <i><?php $dates = date("d/m/Y"); echo ($dates); ?></i></td>
                                        <td class="fw-bolder tol" id="tol"></td>
                                        <td class="fw-bolder"><i>PayStack</i></td>
                                    </tr>
                                </tbody>
                            </table><br>
                            <p>Thank you for your order, please click the button below to pay with paystack.</p>
                            <div class="button d-flex ">
                                <form action="payment.php" method="POST" id="paymentForm">
                                    <input type="hidden" id="first-name" name="firstname" class="form-control" value="<?php echo $_SESSION['firstname']; ?>" required/>
                                    <input type="hidden" id="last-name" name="lastname" class="form-control" value="<?php echo $_SESSION['lastname']; ?>" required/>
                                    <input type="hidden" id="email-address" name="email" class="form-control" value="<?php echo $_SESSION['email']; ?>" required/>
                                    <input type="hidden" id="amount" name="amount" class="form-control" value="<?php echo $_SESSION['amount']; ?>" required/>
                                    <div class="form-submit">
                                        <button type="submit" class="btn btn-warning fw-bolder text mx-5" onclick="payWithPaystack()"> Pay </button>
                                    </div>
                                </form>
                                <!-- <button class="btn btn-warning fw-bolder text mx-5">Pay Now</button> -->
                                <button class="btn btn-warning "><a href="cart.php" class="fw-bolder text text-decoration-none">Cancel Order & Restore  Cart</a></button>
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class=" col-md-5"> 
                        <?php displayCartItems(); ?>
                    </div>
                </div>
            </div>
        </div>


    <!-- <script>
    var storedValue = sessionStorage.getItem("store");

    var grandtotal = document.getElementById('tol');
    grandtotal.innerText = storedValue;
    
</script> -->
<?php 
    include('include/script.php'); 
    include('include/footer.php');
?>