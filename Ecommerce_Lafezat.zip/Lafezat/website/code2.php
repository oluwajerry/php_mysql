<?php
//session_start();
//testimony form
$connection = mysqli_connect("localhost","root","","adminpanel");

if (isset($_POST['testimony'])) {
    $username = stripslashes($_POST['username']);
    $email = stripslashes($_POST['email']);
    $textarea = stripslashes($_POST['text']);

    $query = "INSERT INTO client_testimonies (username,email,comment) VALUES('$username','$email','$textarea')";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "submitted successfully";
        header('location:index.php');
    }
    else 
    {
        $_SESSION['status'] = "Not submitted";
        header('location:index.php');
    }
}

//user register

$connection = mysqli_connect("localhost","root","","adminpanel");

if (isset($_POST['submit'])) 
{
    $firstname = stripslashes($_POST['firstname']);
    $lastname = stripslashes($_POST['lastname']);
    $email = stripslashes($_POST['email']);
    $password = md5($_POST['password']);
    $confirm_password = md5($_POST['confirm_password']);
    $usertype = $_POST['usertype'];

    if ($confirm_password === $password) 
    {
        $query = "INSERT INTO register (firstname,lastname,email,password,usertype) VALUES('$firstname','$lastname','$email','$password','$usertype')";
        $query_run = mysqli_query($connection, $query);
    
        if ($query_run) 
        {
            //$_SESSION['success'] = "submitted successfully";
            echo "submitted successfully";
            header('location:admin/login.php');
        }
        else 
        {
            // $_SESSION['status'] = "Not submitted";
            echo "Not submitted";
            header('location:register.php');
        }
    }
    else 
    {
        echo "password and confirm password does not match";
    }
    
}
?>