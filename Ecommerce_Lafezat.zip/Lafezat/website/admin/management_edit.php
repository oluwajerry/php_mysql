<?php
    include('security.php');  
    include('includes/header.php'); 
    include('includes/navbar.php');
    ?>




<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Edit Management Details </h6>
        </div>
        <div class="card-body">
        <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['edit_management_btn'])) 
                {
                    $id = $_POST['edit_management_id'];
                    
                    $query = "SELECT * FROM management WHERE id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
            <form action="code.php" method="POST">
                <input type="hidden" name="edit_id_management" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">title</label>
                    <textarea name="edit_title" id="textarea2"> <?php echo $row['title']; ?> </textarea>
                </div><br>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">name</label>
                    <textarea name="edit_name" id="textarea3"> <?php echo $row['name']; ?> </textarea>
                </div><br>
                <?php
                    }
                }
                ?>
                <a href="management.php" class="btn btn-danger"> CANCEL</a>
                <button type="submit" name="update_management_btn" class="btn btn-primary">UPDATE</button>
            </form>
        </div>
    </div>

</div













<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
    ?>