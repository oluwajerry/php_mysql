<?php 
   include('security.php'); 
    include('includes/header.php'); 
    include('includes/navbar.php');
?>

<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Edit Service Card</h6>
        </div>
        <div class="card-body">
        <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['editcard_btn'])) 
                {
                    $id = $_POST['editcard_id'];
                    
                    $query = "SELECT * FROM service_card WHERE card_id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
            <form action="code.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="edit_card_id" value="<?php echo $row['card_id']; ?>">
                <div class="form-group">
                    <label for="">image</label>
                    <input type="file" name="edit_image" value="<?php echo $row['image']; ?>" class="form-control" placeholder="Enter image">
                </div>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Title</label>
                    <textarea name="edit_title" id="textarea2" required><?php echo $row['title']; ?></textarea>
                </div><br>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Description</label>
                    <textarea name="edit_description" id="textarea3" required><?php echo $row['description']; ?></textarea>
                </div><br>
                <a href="service_card.php" class="btn btn-danger"> CANCEL</a>
                <button type="submit" name="update_card_btn" class="btn btn-primary">UPDATE</button>
            </form>

            <?php
                    }
                }
            ?>
        </div>
    </div>

</div




<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
?>