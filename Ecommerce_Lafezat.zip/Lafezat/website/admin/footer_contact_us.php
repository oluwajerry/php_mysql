<?php 
include('security.php'); 
    include('includes/header.php'); 
    include('includes/navbar.php');
?>




<!-- Modal -->

<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Contact Us </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="code.php" method="POST">
            <div class="modal-body">
                    
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Telephone no</label>
                    <input type="number" name="telephone" class="form-control" placeholder="Enter phone no" required>
                </div><br>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Address 1</label>
                    <input type="text" name="address1" class="form-control" placeholder="Enter branch address" required>
                </div>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Address 2</label>
                   <input type="text" name="address2" class="form-control" placeholder="Enter Headquarter Address" required>
                </div><br>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                </div><br>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="contactbtn" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
  </div>
</div>

<div class="container-fluid"> 

    <!-- DataTable Example -->

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Contact Details
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addadminprofile">
                Add Contact Us
                </button>
            </h6>
        </div>
        <div class="card-body">

            <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] !='') 
            {
                echo '<h2 class="text-primary"> '.$_SESSION['success'].' </h2>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] !='') 
            {
                echo '<h2 class="text-danger"> '.$_SESSION['status'].' </h2>';
                unset($_SESSION['status']);
            }
            
            ?>

            <div class="table-responsive"> 

                <?php
                
                $connection = mysqli_connect("localhost","root","","adminpanel");
                $query = "SELECT * FROM contact_us";
                $query_run = mysqli_query($connection, $query); 

                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Phone number</th>
                            <th>Address 1</th>
                            <th>Address 2</th>
                            <th>Email</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        
                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            {
                               ?> 
                             <tr>
                                <td> <?php echo $row['id']; ?></td>
                                <td> <?php echo $row['phone_no']; ?></td>
                                <td> <?php echo $row['address_1']; ?></td>
                                <td> <?php echo $row['address_2']; ?></td>
                                <td> <?php echo $row['email']; ?></td>
                                <td>
                                    <form action="footer_contact_edit.php" method="POST">
                                        <input type="hidden" name="edit_contact_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="edit_contact_btn" class="btn btn-success"> EDIT</button>
                                    </form>
                                </td>
                                <td>
                                    <form action="code.php" method="POST">
                                    <input type="hidden" name="delete_contact_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="delete_contact_btn" class="btn btn-danger"> DELETE</button>
                                    </form>
                                </td>
                            </tr>
 
                         <?php
                           }
                        }
                        else 
                        {
                            echo "No Record Found";
                        } 
                        ?>
                   </tbody>
                </table>
            </div>
        </div>
    </div>

</div>




<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
    ?>