<?php 
include('security.php'); 
    include('includes/header.php'); 
    include('includes/navbar.php');
?>


<!-- Modal -->
<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Stock Item </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="code.php" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                    
                <div class="form-group">
                     <label>select item name</label>
                        <select name="item_name" class="form-control"> 
                            <?php
                            
                            $connection = mysqli_connect("localhost", "root", "", "adminpanel");
                            $query = "SELECT * FROM item_table";
                            $query_run = mysqli_query($connection,$query);

                            
                                if (mysqli_num_rows($query_run) > 0 ) 
                                {
                                    foreach ($query_run as $row) 
                                    {
                                        ?>
                                        <option value="<?= $row['item_id']?>"><?= $row['item_name']?></option>
                                        <?php
                                    }
                                }
                                else 
                                {
                                    ?>
                                    <option value="">no option</option>
                                    <?php
                                }
                                ?>
                        </select>
                </div>
                <div class="form-group">
                    <label for="">price</label>
                    <input type="number" name="price" class="form-control" placeholder="Enter item price">
                </div>
                <div class="form-group">
                    <label for="">cost</label>
                    <input type="number" name="cost" class="form-control" placeholder="Enter item cost">
                </div>
                <div class="form-group">
                    <label for="">image</label>
                    <input type="file" name="image" class="form-control" placeholder="Enter item image">
                </div>
                <div class="form-group">
                    <label for="">stock quantity</label>
                    <input type="number" name="stock_qty" class="form-control" placeholder="Enter stock quantity">
                </div>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="stockbtn" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
  </div>
</div>

<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Stock Item details
                <!-- Button trigger modal -->
                <form action="code.php" method="POST">
                    <button type="submit" name="delete_multiple_data" class="btn btn-danger">Delete Multiple Data</button>
                </form>
                <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal" data-bs-target="#addadminprofile">
                Add Stock Items
                </button>
            </h6>
        </div>
        <div class="card-body">

            <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] !='') 
            {
                echo '<h2 class="text-primary"> '.$_SESSION['success'].' </h2>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] !='') 
            {
                echo '<h2 class="text-danger"> '.$_SESSION['status'].' </h2>';
                unset($_SESSION['status']);
            }
            
            ?>

            <div class="table-responsive">

                <?php
                
                $connection = mysqli_connect("localhost","root","","adminpanel");
                $query = "SELECT * FROM stock";
                $query_run = mysqli_query($connection, $query);

                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Check</th>
                            <th>Stock_Id</th>
                            <th>item By id</th>
                            <th>Price</th>
                            <th>Cost</th>
                            <th>Image</th>
                            <th>stock qty</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        
                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            {
                               ?>
                        <tr>
                            <td>
                                <input type="checkbox" onclick="toggleCheckbox(this)" value="<?php echo $row['stock_id'] ?>" <?php echo $row['visible'] == 1 ? "checked" : "" ?> >
                            </td>
                            <td> <?php echo $row['stock_id']; ?></td>
                            <td> <?php echo $row['item_id']; ?></td>
                            <td> <?php echo $row['price']; ?></td>
                            <td> <?php echo $row['cost']; ?></td>
                            <td> <img src="upload/<?php echo $row['image']; ?>" width="100px" height="100px"></td>
                            <td> <?php echo $row['stock_qty']; ?></td>
                            <td>
                                <form action="stock_edit.php" method="POST">
                                    <input type="hidden" name="editstock_id" value="<?php echo $row['stock_id']; ?>">
                                    <button type="submit" name="editstock_btn" class="btn btn-success"> EDIT</button>
                                </form>
                            </td>
                            <td>
                                <form action="code.php" method="POST">
                                <input type="hidden" name="delete_stock_id" value="<?php echo $row['stock_id']; ?>">
                                    <button type="submit" name="stock_btn" class="btn btn-danger"> DELETE</button>
                                </form>
                            </td>
                        </tr>

                        <?php
                            }
                        }
                        else 
                        {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>







<?php 
    include('includes/scripts.php'); 
?>

<script>

    function toggleCheckbox(box) 
    {
        var stock_id = $(box).attr("value");
        if ($(box).prop("checked") == true)  
        {
            var visible = 1;
        }
        else
        {
            var visible = 0;
        }

        var data = {
                    "search_data" : 1,
                    "stock_id" : stock_id,
                    "visible": visible
                };
                
        $.ajax({
            type: "POST",
            url: "code.php",
            data: data,
            success: function (response) {
                //alert("data checked");
            }
        });
    }
</script>

<?
    include('includes/footer.php');
?>