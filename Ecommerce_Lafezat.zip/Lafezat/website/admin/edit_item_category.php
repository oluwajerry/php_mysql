<?php 
   include('security.php'); 
    include('includes/header.php'); 
    include('includes/navbar.php');
?>

<?php
                //RETRIEVE AND EDIT
    $connection = mysqli_connect("localhost","root","","adminpanel");
    if (isset($_POST['edit_item_btn'])) 
    {
        $id = $_POST['edit_item_id'];
                    
        $query = "SELECT * FROM item_table WHERE item_id='$id' ";
         $query_run = mysqli_query($connection, $query);
             ?>
        <div class="container-fluid">

            <!-- DataTable Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 fw-bold text-primary">Edit Item Details</h6>
                </div>
                <div class="card-body">

                    <?php
                    foreach ($query_run as $row) 
                    {
                    ?>
                    <form action="code.php" method="POST">
                        <input type="hidden" name="itemid" value="<?php echo $row['item_id']; ?>">
                        <div class="form-group">
                            <label for="">Item Name</label>
                            <input type="text" name="edititem" value="<?php echo $row['item_name']; ?>" class="form-control" placeholder="Enter item name">
                        </div>
                        <?php
                            }
                        ?>
                        <div class="form-group">
                            <label>select item category</label>
                            <select name="category_id" class="form-control"> 
                                <?php
                                
                                $connection = mysqli_connect("localhost", "root", "", "adminpanel");
                                $query = "SELECT * FROM category_table";
                                $query_run = mysqli_query($connection,$query);

                                
                                    if (mysqli_num_rows($query_run) > 0 ) 
                                    {
                                        foreach ($query_run as $row) 
                                        {
                                            ?>
                                            <option value="<?= $row['category_id']?>"><?= $row['category_name']?></option>
                                            <?php
                                        }
                                    }
                                    else 
                                    {
                                        ?>
                                        <option value="">no option</option>
                                        <?php
                                    }
                                    ?>
                            </select>
                        </div>
                        <?php
                        
                        $query = "SELECT * FROM item_table WHERE item_id='$id' ";
                        $query_run = mysqli_query($connection, $query);

                        foreach ($query_run as $row) 
                        {
                        ?>
                        <div class="form-group">
                            <label for="">Brand Name</label>
                            <input type="text" name="editbrand" value="<?php echo $row['brand_name']; ?>" class="form-control" placeholder="Enter brand name">
                        </div>
                        <a href="shop.php" class="btn btn-danger"> CANCEL</a>
                        <button type="submit" name="itembtn" class="btn btn-primary">UPDATE</button>
                    </form>
                </div>
            </div>

        </div

            <?php
                        }   
    }
    elseif (isset($_POST['edit_category_btn'])) 
    {
        $id = $_POST['edit_category_id'];
                    
        $query = "SELECT * FROM category_table WHERE category_id='$id' ";
        $query_run = mysqli_query($connection, $query);

        
         
        echo "<div class=\"container-fluid\">

            <!-- DataTable Example -->
            <div class=\"card shadow mb-4\">
                <div class=\"card-header py-3\">
                    <h6 class=\"m-0 fw-bold text-primary\">Edit item category </h6>
                </div>
                <div class=\"card-body\">";

                    
                    foreach ($query_run as $row) 
                    {
                    
                echo" 
                   <form action=\"code.php\" method=\"POST\">
                        <input type=\"hidden\" name=\"categoryid\" value=\" $row[category_id]\">
                        <div class=\"form-group\">
                            <label for=\"\">item category</label>
                            <input type=\"text\" name=\"editcategory\" value=\"$row[category_name]\" class=\"form-control\" placeholder=\"Enter username\">
                        </div>
                        <a href=\"shop.php\" class=\"btn btn-danger\"> CANCEL</a>
                        <button type=\"submit\" name=\"categorybtn\" class=\"btn btn-primary\">UPDATE</button>
                    </form>
                </div>
            </div>

        </div>";
        
        
                    }
    }
    else {
        # code...
    }
?>
        




<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
?>