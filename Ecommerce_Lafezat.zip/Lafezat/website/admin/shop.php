<?php 
include('security.php'); 
    include('includes/header.php'); 
    include('includes/navbar.php');
?>




<!-- Modal -->
<div class="modal fade" id="addadminprofile1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Item Name</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="code.php" method="POST">
            <div class="modal-body">
                    
                <div class="form-group">
                    <label for="">item name</label>
                    <input type="text" name="itemname" class="form-control" placeholder="Enter item name">
                </div>
                <div class="form-group">
                    <label>select item category</label>
                        <select name="category_id" class="form-control"> 
                            <?php
                            
                            $connection = mysqli_connect("localhost", "root", "", "adminpanel");
                            $query = "SELECT * FROM category_table";
                            $query_run = mysqli_query($connection,$query);

                            
                                if (mysqli_num_rows($query_run) > 0 ) 
                                {
                                    foreach ($query_run as $row) 
                                    {
                                        ?>
                                        <option value="<?= $row['category_id']?>"><?= $row['category_name']?></option>
                                        <?php
                                    }
                                }
                                else 
                                {
                                    ?>
                                    <option value="">no option</option>
                                    <?php
                                }
                                ?>
                        </select>
                </div>
                <div class="form-group">
                    <label for="">brand name</label>
                    <input type="text" name="brand" class="form-control" placeholder="Enter item brand name">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="item_btn" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addadminprofile2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Add Item Category</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="code.php" method="POST">
            <div class="modal-body">
                    
                <div class="form-group">
                    <label for="">item category</label>
                    <select name="category" class="form-control">
                        <option value="Batteries">Batteries</option>
                        <option value="Inverters">Inverters</option>
                        <option value="Generators">Generators</option>
                        <option value="Uncategorized">Uncategorized</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="category_btn" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
  </div>
</div>

<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex">
            <h6 class="m-0 fw-bold text-primary">Add Item details
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addadminprofile1">
                Add 
                </button>
            </h6>
            <h6 class="m-0 fw-bold text-primary mx-5">Add Item Category
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addadminprofile2">
                Add 
                </button>
            </h6>
        </div>
        <div class="card-body">

            <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] !='') 
            {
                echo '<h3 class="text-primary"> '.$_SESSION['success'].' </h3>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] !='') 
            {
                echo '<h3 class="text-danger"> '.$_SESSION['status'].' </h3>';
                unset($_SESSION['status']);
            }
            
            ?>

            <div class="table-responsive">

                <?php
                
                $connection = mysqli_connect("localhost","root","","adminpanel");
                $query = "SELECT * FROM item_table";
                $query_run = mysqli_query($connection, $query);

                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Item id</th>
                            <th>Item name</th>
                            <th>category by Id</th>
                            <th>Brand name</th>
                            <th>Stock level</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        
                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            {
                               ?>
                        <tr>
                            <td> <?php echo $row['item_id']; ?></td>
                            <td> <?php echo $row['item_name']; ?></td>
                            <td> <?php echo $row['item_category']; ?></td>
                            <td> <?php echo $row['brand_name']; ?></td>
                            <td> <?php echo $row['stock_level']; ?></td>
                            <td>
                                <form action="edit_item_category.php" method="POST">
                                    <input type="hidden" name="edit_item_id" value="<?php echo $row['item_id']; ?>">
                                    <button type="submit" name="edit_item_btn" class="btn btn-success"> EDIT</button>
                                </form>
                            </td>
                            <td>
                                <form action="code.php" method="POST">
                                <input type="hidden" name="delete_item_id" value="<?php echo $row['item_id']; ?>">
                                    <button type="submit" name="delete_item_btn" class="btn btn-danger"> DELETE</button>
                                </form>
                            </td>
                        </tr>

                        <?php
                            }
                        }
                        else 
                        {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>
            </div><br><br><br><br>
            <div class="table-responsive">

                <?php
                
                $connection = mysqli_connect("localhost","root","","adminpanel");
                $query = "SELECT * FROM category_table";
                $query_run = mysqli_query($connection, $query);

                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>category id</th>
                            <th>category name</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        
                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            {
                               ?>
                        <tr>
                            <td> <?php echo $row['category_id']; ?></td>
                            <td> <?php echo $row['category_name']; ?></td>
                            <td>
                                <form action="edit_item_category.php" method="POST">
                                    <input type="hidden" name="edit_category_id" value="<?php echo $row['category_id']; ?>">
                                    <button type="submit" name="edit_category_btn" class="btn btn-success"> EDIT</button>
                                </form>
                            </td>
                            <td>
                                <form action="code.php" method="POST">
                                <input type="hidden" name="delete_category_id" value="<?php echo $row['category_id']; ?>">
                                    <button type="submit" name="delete_category_btn" class="btn btn-danger"> DELETE</button>
                                </form>
                            </td>
                        </tr>

                        <?php
                            }
                        }
                        else 
                        {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>




<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
?>