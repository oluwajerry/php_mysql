<?php
    include('security.php');  
    include('includes/header.php'); 
    include('includes/navbar.php');
    ?>




<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Edit Image Slide </h6>
        </div>
        <div class="card-body">
        <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['edit_slide_btn'])) 
                {
                    $id = $_POST['edit_slide_id'];
                    
                    $query = "SELECT * FROM slide_table WHERE slide_id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
            <form action="code.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="edit_id_slide" value="<?php echo $row['slide_id']; ?>">
                <div class="form-group">
                    <label for="">Slide Name</label>
                    <input type="text" name="edit_slide_name" class="form-control" value="<?php echo $row['slide_name']; ?>" required>
                </div><br>
                <div class="form-group">
                    <label for="">Slide image</label>
                    <input type="file" name="edit_slide_image" class="form-control" value="<?php echo $row['slide_image']; ?>" >
                </div><br>
                <?php
                    }
                }
                ?>
                <a href="slider.php" class="btn btn-danger"> CANCEL</a>
                <button type="submit" name="update_slide_btn" class="btn btn-primary">UPDATE</button>
            </form>
        </div>
    </div>

</div













<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
    ?>