<?php
    include('security.php');  
    include('includes/header.php'); 
    include('includes/navbar.php');
    ?>

    <?php
    
       //DELETE

       if (isset($_POST['delete_btn'])) 
       {
           $id = $_POST['delete_id'];
           
           $query = "DELETE FROM client_testimonies WHERE id='$id' ";
           $query_run = mysqli_query($connection, $query);
       
           if ($query_run) 
           {
               $_SESSION['success'] = "Your Data Is Deleted Successfully";
               header('location:clientCom.php');
           }
           else 
           {
               $_SESSION['status'] = "Your Data Is Not Deleted Successfully";
               header('location:clientCom.php');
           }
       }
    
    ?>

<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h4 class="m-0 fw-bold text-primary">
                Client Testimonies
            </h4>
        </div>
        <div class="card-body">

            <?php
            if (isset($_SESSION['success']) && $_SESSION['success'] !='') 
            {
                echo '<h2 class="text-primary"> '.$_SESSION['success'].' </h2>';
                unset($_SESSION['success']);
            }

            if (isset($_SESSION['status']) && $_SESSION['status'] !='') 
            {
                echo '<h2 class="text-danger"> '.$_SESSION['status'].' </h2>';
                unset($_SESSION['status']);
            }
            
            ?>

            <div class="table-responsive">

                <?php
                
                $connection = mysqli_connect("localhost","root","","adminpanel");
                $query = "SELECT * FROM client_testimonies";
                $query_run = mysqli_query($connection, $query);

                ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Comment</th>
                            <th>Status</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        
                        if (mysqli_num_rows($query_run) > 0) 
                        {
                            while ($row = mysqli_fetch_assoc($query_run)) 
                            {
                               ?>
                        <tr>
                            <td> <?php echo $row['id']; ?></td>
                            <td> <?php echo $row['username']; ?></td>
                            <td> <?php echo $row['email']; ?></td>
                            <td> <?php echo $row['comment']; ?></td>
                            <td> <?php echo $row['status']; ?></td>
                            <td>
                                <form action="clientComEdit.php" method="POST">
                                <input type="hidden" name="edit_comment_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="edit_comment_btn" class="btn btn-success"> EDIT</button>
                                </form>
                            </td>
                            <td>
                                <form action="code.php" method="POST">
                                <input type="hidden" name="delete_comment_id" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="delete_comment_btn" class="btn btn-danger"> DELETE</button>
                                </form>
                            </td>
                        </tr>

                        <?php
                            }
                        }
                        else 
                        {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>




<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
    ?>