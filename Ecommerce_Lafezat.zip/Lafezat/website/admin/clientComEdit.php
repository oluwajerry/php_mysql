<?php
    include('security.php');  
    include('includes/header.php'); 
    include('includes/navbar.php');
    ?>




<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Edit Client Comment</h6>
        </div>
        <div class="card-body">
        <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['edit_comment_btn'])) 
                {
                    $id = $_POST['edit_comment_id'];
                    
                    $query = "SELECT * FROM client_testimonies WHERE id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
            <form action="code.php" method="POST">
                <input type="hidden" name="edit_id_comment" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="">name</label>
                    <input type="text" name="edit_username" class="form-control" value="<?php echo $row['username']; ?>">
                </div>
                <div class="form-group">
                    <label for="">email</label>
                    <input type="email" name="edit_email" class="form-control" value="<?php echo $row['email']; ?>">
                </div><br>
                <div class="form-group">
                    <textarea name="editor1"><?php echo htmlspecialchars($row['comment']); ?></textarea>
                    <!-- <textarea name="edit_text" cols="30" rows="3" class="form-control"> <?php //echo htmlspecialchars($row['comment']); ?> </textarea> -->
                </div><br>
                <div class="form-group">
                    <label for="">status</label>
                    <input type="number" name="edit_status" class="form-control" value="<?php echo $row['status']; ?>">
                </div><br>
                <?php
                    }
                }
                ?>
                <a href="clientCom.php" class="btn btn-danger"> CANCEL</a>
                <button type="submit" name="update_comment_btn" class="btn btn-primary">UPDATE</button>
            </form>
        </div>
    </div>

</div













<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
    ?>