<?php
    include('security.php');  
    include('includes/header.php'); 
    include('includes/navbar.php');
    ?>




<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Edit Contact Us </h6>
        </div>
        <div class="card-body">
        <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['edit_contact_btn'])) 
                {
                    $id = $_POST['edit_contact_id'];
                    
                    $query = "SELECT * FROM contact_us WHERE id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
            <form action="code.php" method="POST">
                <input type="hidden" name="edit_id_contact" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Telephone no</label>
                    <input type="number" name="edit_telephone" value="<?php echo $row['phone_no']; ?>" class="form-control"  required>
                </div><br>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Address 1</label>
                    <input type="text" name="edit_address1" value="<?php echo $row['address_1']; ?>" class="form-control"  required>
                </div>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Address 2</label>
                   <input type="text" name="edit_address2" value="<?php echo $row['address_2']; ?>" class="form-control"  required>
                </div><br>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Enter Email</label>
                    <input type="email" name="edit_email" value="<?php echo $row['email']; ?>" class="form-control"  required>
                </div><br>
                <?php
                    }
                }
                ?>
                <a href="footer_contact_us.php" class="btn btn-danger"> CANCEL</a>
                <button type="submit" name="update_contact_btn" class="btn btn-primary">UPDATE</button>
            </form>
        </div>
    </div>

</div













<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
    ?>