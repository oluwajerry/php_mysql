<?php
    include('security.php');  
    include('includes/header.php'); 
    include('includes/navbar.php');
    ?>




<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Edit Our Service Details </h6>
        </div>
        <div class="card-body">
        <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['edit_service_btn'])) 
                {
                    $id = $_POST['edit_service_id'];
                    
                    $query = "SELECT * FROM service WHERE id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
            <form action="code.php" method="POST">
                <input type="hidden" name="edit_id_service" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Subtitle</label>
                    <textarea name="edit_subtitle" id="textarea2"> <?php echo $row['sub_title']; ?> </textarea>
                </div><br>
                <div class="form-group">
                    <label for="" class="fw-bolder text-primary">Description</label>
                    <textarea name="edit_description" id="textarea3"> <?php echo $row['description']; ?> </textarea>
                </div><br>
                <?php
                    }
                }
                ?>
                <a href="service.php" class="btn btn-danger"> CANCEL</a>
                <button type="submit" name="update_service_btn" class="btn btn-primary">UPDATE</button>
            </form>
        </div>
    </div>

</div













<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
    ?>