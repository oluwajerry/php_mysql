<?php
include('security.php'); 
                                // REGISTRATION

$connection = mysqli_connect("localhost","root","","adminpanel");

if (isset($_POST['registerbtn'])) 
{
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $cpassword = md5($_POST['confirmpassword']);
    $usertype = $_POST['usertype'];

    if ($password === $cpassword ) 
    {
        $query = "INSERT INTO register(firstname,lastname,email,password,usertype) VALUES('$firstname','$lastname','$email','$password','$usertype')";
        $query_run = mysqli_query($connection, $query);
        if ($query_run) 
        {
            $_SESSION['success'] = "Admin Profile Added";
            header('location:register.php');
        }
        else 
        {
            $_SESSION['status'] = "Admin Profile Not Added";
            header('location:register.php');
        }
    }
    else 
    {
        $_SESSION['status'] = "password and confirm password does not match";
        header('location:register.php');
    }
   
}





            //UPDATE

if (isset($_POST['updatebtn'])) 
{
    $id = $_POST['edit_id'];
    $firstname = $_POST['edit_firstname'];
    $lastname = $_POST['edit_lastname'];
    $email = $_POST['edit_email'];
    $password = md5($_POST['edit_password']);
    $usertype = $_POST['update_usertype'];
    
    $query = "UPDATE register SET firstname = '$firstname', lastname = '$lastname', email = '$email', password = '$password', usertype = '$usertype' WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Your Data Is Updated Successfully";
        header('location:register.php');
    }
    else 
    {
        $_SESSION['status'] = "Your Data Is Not Updated";
        header('location:register.php');
    }

}
    //DELETE

    if (isset($_POST['delete_btn'])) 
{
    $id = $_POST['delete_id'];
    
    $query = "DELETE FROM register WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Your Data Is Deleted Successfully";
        header('location:register.php');
    }
    else 
    {
        $_SESSION['status'] = "Your Data Is Not Deleted ";
        header('location:register.php');
    }
}



//ITEM and CATEGORY INPUT
$connection = mysqli_connect("localhost","root","","adminpanel");

if (isset($_POST['item_btn'])) 
{
    $itemname = $_POST['itemname'];
    $category_id = $_POST['category_id'];
    $brand = $_POST['brand'];

        $query = "INSERT INTO item_table (item_name,item_category,brand_name) VALUES('$itemname','$category_id','$brand')";

        $query_run = mysqli_query($connection, $query);
        if ($query_run) 
        {
            $_SESSION['success'] = "Item Added Successfully";
            header('location:shop.php');
        }
        else 
        {
            $_SESSION['status'] = "Item Not Added";
            header('location:shop.php');
        }
   
}

if (isset($_POST['category_btn'])) 
{
    $category = $_POST['category'];

    $query = "INSERT INTO category_table (category_name) VALUES('$category')";
    $query_run = mysqli_query($connection, $query);
        if ($query_run) 
        {
            $_SESSION['success'] = "Item Category Added Successfully";
            header('location:shop.php');
        }
        else 
        {
            $_SESSION['status'] = "Item Category Not Added";
            header('location:shop.php');
        }
   
}


 //DELETE ITEM

 if (isset($_POST['delete_item_btn'])) 
 {
     $id = $_POST['delete_item_id'];
     
     $query = "DELETE FROM item_table WHERE item_id='$id' ";
     $query_run = mysqli_query($connection, $query);
 
     if ($query_run) 
     {
         $_SESSION['success'] = "item Deleted Successfully";
         header('location:shop.php');
     }
     else 
     {
         $_SESSION['status'] = "item Not Deleted ";
         header('location:shop.php');
     }
 }


 //DELETE CATEGORY

 if (isset($_POST['delete_category_btn'])) 
 {
     $id = $_POST['delete_category_id'];
     
     $query = "DELETE FROM category_table WHERE category_id='$id' ";
     $query_run = mysqli_query($connection, $query);
 
     if ($query_run) 
     {
         $_SESSION['success'] = "Category Deleted Successfully";
         header('location:shop.php');
     }
     else 
     {
         $_SESSION['status'] = "Category Not Deleted";
         header('location:shop.php');
     }
 }


 // item and category update

 if (isset($_POST['itembtn'])) 
{
    $id = $_POST['itemid'];
    $itemname = $_POST['edititem'];
    $category_id = $_POST['category_id'];
    $editbrand = $_POST['editbrand'];
    
    $query = "UPDATE item_table SET item_name = '$itemname',item_category = '$category_id',brand_name = '$editbrand' WHERE item_id='$id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Item Updated Successfully";
        header('location:shop.php');
    }
    else 
    {
        $_SESSION['status'] = "Item Not Updated";
        header('location:shop.php');
    }

}

if (isset($_POST['categorybtn'])) 
{
    $id = $_POST['categoryid'];
    $category = $_POST['editcategory'];
    
    $query = "UPDATE category_table SET category_name = '$category' WHERE category_id='$id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Item category Updated Successfully";
        header('location:shop.php');
    }
    else 
    {
        $_SESSION['status'] = "Item category Not Updated";
        header('location:shop.php');
    }

}


//DELETE CLIENT COMMENT
if (isset($_POST['delete_comment_btn'])) 
{
    $id = $_POST['delete_comment_id'];
    
    $query = "DELETE FROM client_testimonies WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Data Is Deleted Successfully";
        header('location:clientCom.php');
    }
    else 
    {
        $_SESSION['status'] = "Data Is Not Deleted ";
        header('location:clientCom.php');
    }
}

//EDIT CLIENT COMMENT

if (isset($_POST['update_comment_btn'])) 
{
    $id = $_POST['edit_id_comment'];
    $username = stripslashes($_POST['edit_username']);
    $email = stripslashes($_POST['edit_email']);
    $comment = stripslashes($_POST['editor1']);
    $status = $_POST['edit_status'];
    
    $query = "UPDATE client_testimonies SET username = '$username',email = '$email',comment = '$comment',status = $status 
    WHERE id='$id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "comment Updated Successfully";
        header('location:clientCom.php');
    }
    else 
    {
        $_SESSION['status'] = "comment Not Updated";
        header('location:clientCom.php');
    }

}



// STOCK INPUT TO DB

//$connection = mysqli_connect("localhost","root","","adminpanel");

if (isset($_POST['stockbtn'])) 
{
    $item_name = $_POST['item_name'];
    $price = $_POST['price'];
    $cost = $_POST['cost'];
    $image = $_FILES["image"]["name"];
    $stock_qty = $_POST['stock_qty'];
                           
     $validate_img_extension = $_FILES["image"]["type"] == "image/jpg" ||
                            $_FILES["image"]["type"] == "image/png" ||    
                            $_FILES["image"]["type"] == "image/jpeg" 
    ;

    if($validate_img_extension)
    { 

        /*if (file_exists("upload/" . $_FILES["image"]["name"])) 
        {
        $store =  $_FILES["image"]["name"];
        $_SESSION['status'] = "Image already exists. '.$store.' ";
        header('location: stock.php');
        }
        else 
        {*/
            $query = "INSERT INTO stock (item_id,price,cost,image,stock_qty) VALUES ($item_name,'$price','$cost','$image','$stock_qty')";
                                        
            $query_run = mysqli_query($connection, $query);

            $query2 = mysqli_query($connection, "SELECT stock_level FROM item_table WHERE item_id = $item_name");
            $row = mysqli_fetch_array($query2);
            $existingStockLevel = $row['stock_level'];


            $newStock_level = $existingStockLevel + $stock_qty;

            $query3= mysqli_query($connection, "UPDATE item_table SET stock_level = $newStock_level WHERE item_id = $item_name");

            if ($query_run && $query2 && $query3) 
            {
                move_uploaded_file($_FILES["image"]['tmp_name'], "upload/".$_FILES["image"]["name"]);
                $_SESSION['success'] = "Stock Item Added Successfully";
                header('location:stock.php');
            }
            else 
            {
                $_SESSION['status'] = "Stock Item Not Added";
                header('location:stock.php');
            }
        // }
    }
    else 
    {
        $_SESSION['status'] = "Only PNG,JPG and JPEG images are allowed ";
            header('location:stock.php');
    } 
    
}
                            
                           
                           

//DELETE STOCK ITEMS
$connection = mysqli_connect("localhost","root","","adminpanel");
if (isset($_POST['stock_btn'])) 
{
    $id = $_POST['delete_stock_id'];
    
    $sql = "SELECT image FROM stock WHERE stock_id = '$id'";
    $result = mysqli_query($connection, $sql);
    $row = mysqli_fetch_assoc($result);
    $filename = $row['image'];

    $image_path = "upload/" . $filename;
    unlink($image_path);

    $query = "DELETE FROM stock WHERE stock_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Stock Deleted Successfully";
        header('location:stock.php');
    }
    else 
    {
        $_SESSION['status'] = "Stock Not Deleted";
        header('location:stock.php');
    }
}

// UPDATE STOCK 
$connection = mysqli_connect("localhost","root","","adminpanel");

if (isset($_POST['update_stock_btn'])) 
{
    $id = $_POST['edit_stock_id'];
    $item_id = $_POST['item_name'];
    $price = $_POST['edit_price'];
    $cost = $_POST['edit_cost'];
    $image = $_FILES["edit_image"]["name"]; 
    $stock_qty = $_POST['edit_stock_qty'];

     $validate_img_extension = $_FILES["edit_image"]["type"] == "image/jpg" ||
                            $_FILES["edit_image"]["type"] == "image/png" ||    
                            $_FILES["edit_image"]["type"] == "image/jpeg" 
    ;

    if ($validate_img_extension) 
    { 
        $img_query = "SELECT * FROM stock WHERE stock_id = '$id' ";
        $img_query_run = mysqli_query($connection, $img_query);
        foreach ($img_query_run as $img_row) 
        {
            if ($image == NULL) 
            {
                //update with existing image
                $img_content = $img_row['image']; 
            }
            else 
            {
                //update with new image and delete the old image
                if ($img_path = "upload/". $img_row['image']) 
                {
                    unlink($img_path);
                    $img_content = $image;
                }
                
            }
        }
        
        $query = "UPDATE stock 
        SET item_id = '$item_id', price = '$price', cost = '$cost', image = '$img_content' , stock_qty = '$stock_qty'  
        WHERE stock_id='$id' ";
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            if ($image == NULL) 
            {
                //update with existing image
                $_SESSION['success'] = "stock Updated with existing image";
                header('location:stock.php');
            }
            else 
            {
                //update with new image and delete the old image
                move_uploaded_file($_FILES["edit_image"]['tmp_name'], "upload/".$_FILES["edit_image"]["name"]);
                $_SESSION['success'] = "Stock Item Added Successfully";
                header('location:stock.php');
                
            }
            
        }
        else 
        {
            $_SESSION['status'] = "stock Not Updated";
            header('location:stock.php');
        }
    }
    else 
    {
        $_SESSION['status'] = "Only PNG,JPG and JPEG images are allowed ";
            header('location:stock.php');
    } 
}

// jquery visible submit to db
if (isset($_POST['search_data'])) {
        
    $stock_id = $_POST['stock_id'];
    $visible = $_POST['visible'];

    $query= "UPDATE stock SET visible = '$visible' WHERE stock_id ='$stock_id' ";
    $query_run= mysqli_query($connection, $query);

    if (!$query_run) {
        echo "Error: " . mysqli_error($connection);
    }

}

// multiple button delete
if (isset($_POST['delete_multiple_data']))
{
    $id = "1";

    $query= "DELETE FROM stock WHERE visible = '$id' ";
    $query_run= mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Your Data is deleted";
        header('location: stock.php');
    }
    else 
    {
        $_SESSION['status'] = "Your Data is not deleted";
        header('location: stock.php');
    }

}


// SLIDE ADD TO DATABASE

if (isset($_POST['slidebtn'])) 
{
    $slide_name = $_POST['slide_name'];
    $slide_image = $_FILES["slide_image"]["name"];
                           
     $validate_img_extension = $_FILES["slide_image"]["type"] == "image/jpg" ||
                                $_FILES["slide_image"]["type"] == "image/png" ||    
                                $_FILES["slide_image"]["type"] == "image/jpeg" 
    ;

    if($validate_img_extension)
    { 

        if (file_exists("slide_upload/" . $_FILES["slide_image"]["name"])) 
        {
            $store =  $_FILES["slide_image"]["name"];
            $_SESSION['status'] = "slide image already exists. '.$store.' ";
            header('location: slider.php');
        }
        else 
        {
            $query = "INSERT INTO slide_table (slide_name,slide_image) VALUES ('$slide_name','$slide_image')";
                                        
            $query_run = mysqli_query($connection, $query);

            if ($query_run) 
            {
                move_uploaded_file($_FILES["slide_image"]['tmp_name'], "slide_upload/".$_FILES["slide_image"]["name"]);
                $_SESSION['success'] = "Slide image  Added Successfully";
                header('location:slider.php');
            }
            else 
            {
                $_SESSION['status'] = "slide Image Not Added";
                header('location:slider.php');
            }
        }
    }
    else 
    {
        $_SESSION['status'] = "Only PNG,JPG and JPEG images are allowed ";
            header('location:slider.php');
    } 
    
}


// DELETE SLIDE

if (isset($_POST['delete_slide_btn'])) 
{
    $id = $_POST['delete_slide_id'];
    
    $sql = "SELECT slide_image FROM slide_table WHERE slide_id = '$id'";
    $result = mysqli_query($connection, $sql);
    $row = mysqli_fetch_assoc($result);
    $filename = $row['slide_image'];

    $image_path = "slide_upload/" . $filename;
    unlink($image_path);


    $query = "DELETE FROM slide_table WHERE slide_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "slide image Deleted Successfully";
        header('location:slider.php');
    }
    else 
    {
        $_SESSION['status'] = "slide image Not Deleted";
        header('location:slider.php');
    }
}

//UPDATE SLIDE IMAGE

if (isset($_POST['update_slide_btn'])) 
{
    $id = $_POST['edit_id_slide'];
    $edit_slide_name = $_POST['edit_slide_name'];
    $edit_slide_image = $_FILES["edit_slide_image"]["name"]; 

     $validate_img_extension = $_FILES["edit_slide_image"]["type"] == "image/jpg" ||
                                $_FILES["edit_slide_image"]["type"] == "image/png" ||    
                                $_FILES["edit_slide_image"]["type"] == "image/jpeg" 
    ;

    if ($validate_img_extension) 
    { 
        $img_query = "SELECT * FROM slide_table WHERE slide_id = '$id' ";
        $img_query_run = mysqli_query($connection, $img_query);
        foreach ($img_query_run as $img_row) 
        {
            if ($edit_slide_image == NULL) 
            {
                //update with existing image
                $img_content = $img_row['slide_image']; 
            }
            else 
            {
                //update with new image and delete the old image
                if ($img_path = "slide_upload/". $img_row['slide_image']) 
                {
                    unlink($img_path);
                    $img_content = $edit_slide_image;
                }
                
            }
        }
        
        $query = "UPDATE slide_table 
        SET slide_name = '$edit_slide_name', slide_image = '$img_content'  
        WHERE slide_id='$id' ";
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            if ($edit_slide_image == NULL) 
            {
                //update with existing image
                $_SESSION['success'] = "slide Updated with existing image";
                header('location:slider.php');
            }
            else 
            {
                //update with new image and delete the old image
                move_uploaded_file($_FILES["edit_slide_image"]['tmp_name'], "slide_upload/".$_FILES["edit_slide_image"]["name"]);
                $_SESSION['success'] = "slide  Added Successfully";
                header('location:slider.php');
                
            }
            
        }
        else 
        {
            $_SESSION['status'] = "slide Not Updated";
            header('location:slider.php');
        }
    }
    else 
    {
        $_SESSION['status'] = "Only PNG,JPG and JPEG images are allowed ";
            header('location:slider.php');
    } 
}

//  INFO INSERT INTO DATABASE

if (isset($_POST['infobtn'])) 
{
    $title = $_POST['title'];
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
                           
      
    $query = "INSERT INTO our_info (title,sub_title,description) VALUES ('$title','$subtitle','$description')";
                                        
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "info  Added Successfully";
        header('location:slide_info.php');
    }
    else 
    {
        $_SESSION['status'] = "info Not Added";
        header('location:slide_info.php');
    }
}

// INFO UPDATE

if (isset($_POST['update_info_btn'])) 
{
    $id = $_POST['edit_id_info'];
    $edit_title = $_POST['edit_title'];
    $edit_subtitle = $_POST['edit_subtitle'];
    $edit_description = $_POST['edit_description'];
    
    $query = "UPDATE our_info SET title = '$edit_title',sub_title = '$edit_subtitle',description = '$edit_description' WHERE id='$id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Info Updated Successfully";
        header('location:slide_info.php');
    }
    else 
    {
        $_SESSION['status'] = "Info Not Updated";
        header('location:slide_info.php');
    }

}

//INFO DELETE

if (isset($_POST['delete_info_btn'])) 
{
    $id = $_POST['delete_info_id'];
    
    $query = "DELETE FROM our_info WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Info Is Deleted Successfully";
        header('location:slide_info.php');
    }
    else 
    {
        $_SESSION['status'] = "Info Is Not Deleted ";
        header('location:slide_info.php');
    }
}


//INSERT OUR BACKGROUND INTO DB

if (isset($_POST['backgroundbtn'])) 
{
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
                           
      
    $query = "INSERT INTO our_background (sub_title,description) VALUES ('$subtitle','$description')";
                                        
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "background information  Added Successfully";
        header('location:our_background.php');
    }
    else 
    {
        $_SESSION['status'] = "background information Not Added";
        header('location:our_background.php');
    }
}

//UPDATE BACKGROUND INFO

if (isset($_POST['update_background_btn'])) 
{
    $id = $_POST['edit_id_background'];
    $edit_subtitle = $_POST['edit_subtitle'];
    $edit_description = $_POST['edit_description'];
    
    $query = "UPDATE our_background SET sub_title = '$edit_subtitle',description = '$edit_description' WHERE background_id='$id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "background information Updated Successfully";
        header('location:our_background.php');
    }
    else 
    {
        $_SESSION['status'] = "background information Not Updated";
        header('location:our_background.php');
    }

}

//INFO DELETE

if (isset($_POST['delete_background_btn'])) 
{
    $id = $_POST['delete_background_id'];
    
    $query = "DELETE FROM our_background WHERE background_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "background information Is Deleted Successfully";
        header('location:our_background.php');
    }
    else 
    {
        $_SESSION['status'] = "background information Is Not Deleted ";
        header('location:our_background.php');
    }
}


// INSERT SERVICE INTO DB

if (isset($_POST['servicebtn'])) 
{
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
                           
      
    $query = "INSERT INTO service (sub_title,description) VALUES ('$subtitle','$description')";
                                        
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "service information  Added Successfully";
        header('location:service.php');
    }
    else 
    {
        $_SESSION['status'] = "service information Not Added";
        header('location:service.php');
    }
}


//UPDATE service details

if (isset($_POST['update_service_btn'])) 
{
    $id = $_POST['edit_id_service'];
    $edit_subtitle = $_POST['edit_subtitle'];
    $edit_description = $_POST['edit_description'];
    
    $query = "UPDATE service SET sub_title = '$edit_subtitle',description = '$edit_description' WHERE id='$id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "service information Updated Successfully";
        header('location:service.php');
    }
    else 
    {
        $_SESSION['status'] = "service information Not Updated";
        header('location:service.php');
    }

}

//SERVICE DETAILS DELETE

if (isset($_POST['delete_service_btn'])) 
{
    $id = $_POST['delete_service_id'];
    
    $query = "DELETE FROM service WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "service information Is Deleted Successfully";
        header('location:service.php');
    }
    else 
    {
        $_SESSION['status'] = "service information Is Not Deleted ";
        header('location:service.php');
    }
}


// CARD INSERT INTO DATABASE

if (isset($_POST['cardbtn'])) 
{
    $image = $_FILES["image"]["name"];
    $title = $_POST['title'];
    $description = $_POST['description'];
                           
     $validate_img_extension = $_FILES["image"]["type"] == "image/jpg" ||
                            $_FILES["image"]["type"] == "image/png" ||    
                            $_FILES["image"]["type"] == "image/jpeg" 
    ;

    if($validate_img_extension)
    { 

        if (file_exists("card_upload/" . $_FILES["image"]["name"])) 
        {
        $store =  $_FILES["image"]["name"];
        $_SESSION['status'] = "Image already exists. '.$store.' ";
        header('location: service_card.php');
        }
        else 
        {
            $query = "INSERT INTO service_card (image,title,description) VALUES ('$image','$title','$description')";
                                        
            $query_run = mysqli_query($connection, $query);

            if ($query_run) 
            {
                move_uploaded_file($_FILES["image"]['tmp_name'], "card_upload/".$_FILES["image"]["name"]);
                $_SESSION['success'] = "service card Item Added Successfully";
                header('location:service_card.php');
            }
            else 
            {
                $_SESSION['status'] = "service_card Item Not Added";
                header('location:service_card.php');
            }
         }
    } 
    else 
    {
        $_SESSION['status'] = "Only PNG,JPG and JPEG images are allowed ";
            header('location:service_card.php');
    } 
    
}
                            
                           
                           

//DELETE SERVICE CARD
$connection = mysqli_connect("localhost","root","","adminpanel");
if (isset($_POST['card_btn'])) 
{
    $id = $_POST['delete_card_id'];
    
    $sql = "SELECT image FROM service_card WHERE card_id = '$id'";
    $result = mysqli_query($connection, $sql);
    $row = mysqli_fetch_assoc($result);
    $filename = $row['image'];

    $image_path = "card_upload/" . $filename;
    unlink($image_path);

    $query = "DELETE FROM service_card WHERE card_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "service card Deleted Successfully";
        header('location:service_card.php');
    }
    else 
    {
        $_SESSION['status'] = "service card Not Deleted";
        header('location:service_card.php');
    }
}

// UPDATE SERVICE CARD 
$connection = mysqli_connect("localhost","root","","adminpanel");

if (isset($_POST['update_card_btn'])) 
{
    $id = $_POST['edit_card_id'];
    $image = $_FILES["edit_image"]["name"]; 
    $edit_title = $_POST['edit_title'];
    $edit_description = $_POST['edit_description'];

     $validate_img_extension = $_FILES["edit_image"]["type"] == "image/jpg" ||
                            $_FILES["edit_image"]["type"] == "image/png" ||    
                            $_FILES["edit_image"]["type"] == "image/jpeg" 
    ;

    if ($validate_img_extension) 
    { 
        $img_query = "SELECT * FROM service_card WHERE card_id = '$id' ";
        $img_query_run = mysqli_query($connection, $img_query);
        foreach ($img_query_run as $img_row) 
        {
            if ($image == NULL) 
            {
                //update with existing image
                $img_content = $img_row['image']; 
            }
            else 
            {
                //update with new image and delete the old image
                if ($img_path = "card_upload/". $img_row['image']) 
                {
                    unlink($img_path);
                    $img_content = $image;
                }
                
            }
        }
        
        $query = "UPDATE service_card 
                    SET image = '$img_content' , title = '$edit_title', description = '$edit_description'  
                    WHERE card_id='$id' ";
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            if ($image == NULL) 
            {
                //update with existing image
                $_SESSION['success'] = "service card Updated with existing image";
                header('location:service_card.php');
            }
            else 
            {
                //update with new image and delete the old image
                move_uploaded_file($_FILES["edit_image"]['tmp_name'], "card_upload/".$_FILES["edit_image"]["name"]);
                $_SESSION['success'] = "service card Item Added Successfully";
                header('location:service_card.php');
                
            }
            
        }
        else 
        {
            $_SESSION['status'] = "service card Not Updated";
            header('location:service_card.php');
        }
    }
    else 
    {
        $_SESSION['status'] = "Only PNG,JPG and JPEG images are allowed ";
            header('location:service_card.php');
    } 
}


// CONTACT US INSERT INTO DB

if (isset($_POST['contactbtn'])) 
{
    $phone = $_POST['telephone'];
    $address = $_POST['address1'];
    $address2 = $_POST['address2'];
    $email = $_POST['email'];
                           
      
    $query = "INSERT INTO contact_us (phone_no,address_1,address_2,email) VALUES ('$phone','$address','$address2','$email')";
                                        
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Contact Us Added Successfully";
        header('location:footer_contact_us.php');
    }
    else 
    {
        $_SESSION['status'] = "Contact Us Not Added";
        header('location:footer_contact_us.php');
    }
}


//UPDATE CONTACT US

if (isset($_POST['update_contact_btn'])) 
{
    $id = $_POST['edit_id_contact'];
    $edit_telephone = $_POST['edit_telephone'];
    $edit_address1 = $_POST['edit_address1'];
    $edit_address2 = $_POST['edit_address2'];
    $edit_email = $_POST['edit_email'];
    
    $query = "UPDATE contact_us SET phone_no = '$edit_telephone',address_1 = '$edit_address1',address_2 = '$edit_address2',
                email = '$edit_email' WHERE id='$id'";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Contact Us Updated Successfully";
        header('location:footer_contact_us.php');
    }
    else 
    {
        $_SESSION['status'] = "Contact Us Not Updated";
        header('location:footer_contact_us.php');
    }

}


//DELETE CONTACT US

if (isset($_POST['delete_contact_btn'])) 
{
    $id = $_POST['delete_contact_id'];
    
    $query = "DELETE FROM contact_us WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "Contact Us Is Deleted Successfully";
        header('location:footer_contact_us.php');
    }
    else 
    {
        $_SESSION['status'] = "Contact Us Is Not Deleted ";
        header('location:footer_contact_us.php');
    }
}


//INSERT PORTFOLIO

if (isset($_POST['portfoliobtn'])) 
{
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
    
    // Check if the editor content is empty
    if (empty(trim(strip_tags($subtitle)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: portfolio.php');
    }
    elseif (empty(trim(strip_tags($description)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: portfolio.php');
    }
    else 
    {
        $query = "INSERT INTO portfolio (sub_title,description) VALUES ('$subtitle','$description')";
                                            
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "portfolio  Added Successfully";
            header('location:portfolio.php');
        }
        else 
        {
            $_SESSION['status'] = "portfolio Not Added";
            header('location:portfolio.php');
        }
    } 
    
}

//UPDATE PORTFOLIO

if (isset($_POST['update_portfolio_btn'])) 
{
    $id = $_POST['edit_id_portfolio'];
    $edit_subtitle = $_POST['edit_subtitle'];
    $edit_description = $_POST['edit_description'];
    
    if (empty(trim(strip_tags($edit_subtitle)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: portfolio.php');
    }
    elseif (empty(trim(strip_tags($edit_description)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: portfolio.php');
    }
    else 
    {
        $query = "UPDATE portfolio SET sub_title = '$edit_subtitle',description = '$edit_description' WHERE id='$id'";
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "portfolio Updated Successfully";
            header('location:portfolio.php');
        }
        else 
        {
            $_SESSION['status'] = "portfolio Not Updated";
            header('location:portfolio.php');
        }
    }

}

//PORTFOLIO DELETE

if (isset($_POST['delete_portfolio_btn'])) 
{
    $id = $_POST['delete_portfolio_id'];
    
    $query = "DELETE FROM portfolio WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "portfolio Is Deleted Successfully";
        header('location:portfolio.php');
    }
    else 
    {
        $_SESSION['status'] = "portfolio Is Not Deleted ";
        header('location:portfolio.php');
    }
}



//INSERT MANAGEMENT

if (isset($_POST['managementbtn'])) 
{
    $title = $_POST['title'];
    $name = $_POST['name'];
    
    // Check if the editor content is empty
    if (empty(trim(strip_tags($title)))) 
    {
        $_SESSION['errors'] = "you have to fill all the field.";
        header('location: management.php');
    }
    elseif (empty(trim(strip_tags($name)))) 
    {
        $_SESSION['errors'] = "you have to fill all the field.";
        header('location: management.php');
    }
    else 
    {
        $query = "INSERT INTO management (title,name) VALUES ('$title','$name')";
                                            
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "manager  Added Successfully";
            header('location:management.php');
        }
        else 
        {
            $_SESSION['status'] = "manager Not Added";
            header('location:management.php');
        }
    } 
    
}

//UPDATE MANAGEMENT

if (isset($_POST['update_management_btn'])) 
{
    $id = $_POST['edit_id_management'];
    $edit_title = $_POST['edit_title'];
    $edit_name = $_POST['edit_name'];
    
    if (empty(trim(strip_tags($edit_title)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: management.php');
    }
    elseif (empty(trim(strip_tags($edit_name)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: management.php');
    }
    else 
    {
        $query = "UPDATE management SET title = '$edit_title',name = '$edit_name' WHERE id='$id'";
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "management Updated Successfully";
            header('location:management.php');
        }
        else 
        {
            $_SESSION['status'] = "portfolio Not Updated";
            header('location:management.php');
        }
    }

}

//MANAGEMENT DELETE

if (isset($_POST['delete_management_btn'])) 
{
    $id = $_POST['delete_management_id'];
    
    $query = "DELETE FROM management WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "management Is Deleted Successfully";
        header('location:management.php');
    }
    else 
    {
        $_SESSION['status'] = "management Is Not Deleted ";
        header('location:management.php');
    }
}

//INSERT VISION

if (isset($_POST['visionbtn'])) 
{
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
    
    // Check if the editor content is empty
    if (empty(trim(strip_tags($subtitle)))) 
    {
        $_SESSION['errors'] = "you have to fill all the field.";
        header('location: vision.php');
    }
    elseif (empty(trim(strip_tags($description)))) 
    {
        $_SESSION['errors'] = "you have to fill all the field.";
        header('location: vision.php');
    }
    else 
    {
        $query = "INSERT INTO vision (sub_title,description) VALUES ('$subtitle','$description')";
                                            
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "vision statement  Added Successfully";
            header('location:vision.php');
        }
        else 
        {
            $_SESSION['status'] = "vision statement Not Added";
            header('location:vision.php');
        }
    } 
    
}

//UPDATE VISION

if (isset($_POST['update_vision_btn'])) 
{
    $id = $_POST['edit_id_vision'];
    $edit_title = $_POST['edit_subtitle'];
    $edit_description = $_POST['edit_description'];
    
    if (empty(trim(strip_tags($edit_title)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: vision.php');
    }
    elseif (empty(trim(strip_tags($edit_description)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: vision.php');
    }
    else 
    {
        $query = "UPDATE vision SET sub_title = '$edit_title',description = '$edit_description' WHERE id='$id'";
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "vision statement Updated Successfully";
            header('location:vision.php');
        }
        else 
        {
            $_SESSION['status'] = "vision statement Not Updated";
            header('location:vision.php');
        }
    }

}

//VISION DELETE

if (isset($_POST['delete_vision_btn'])) 
{
    $id = $_POST['delete_vision_id'];
    
    $query = "DELETE FROM vision WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "vision statement Is Deleted Successfully";
        header('location:vision.php');
    }
    else 
    {
        $_SESSION['status'] = "vision statement Is Not Deleted ";
        header('location:vision.php');
    }
}



//INSERT MISSION

if (isset($_POST['missionbtn'])) 
{
    $subtitle = $_POST['subtitle'];
    $description = $_POST['description'];
    
    // Check if the editor content is empty
    if (empty(trim(strip_tags($subtitle)))) 
    {
        $_SESSION['errors'] = "you have to fill all the field.";
        header('location: mission.php');
    }
    elseif (empty(trim(strip_tags($description)))) 
    {
        $_SESSION['errors'] = "you have to fill all the field.";
        header('location: mission.php');
    }
    else 
    {
        $query = "INSERT INTO mission (sub_title,description) VALUES ('$subtitle','$description')";
                                            
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "mission statement  Added Successfully";
            header('location:mission.php');
        }
        else 
        {
            $_SESSION['status'] = "mission statement Not Added";
            header('location:mission.php');
        }
    } 
    
}

//UPDATE MISSION

if (isset($_POST['update_mission_btn'])) 
{
    $id = $_POST['edit_id_mission'];
    $edit_title = $_POST['edit_subtitle'];
    $edit_description = $_POST['edit_description'];
    
    if (empty(trim(strip_tags($edit_title)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: mission.php');
    }
    elseif (empty(trim(strip_tags($edit_description)))) 
    {
        $_SESSION['errors'] = "Please enter some text in the editor.";
        header('location: mission.php');
    }
    else 
    {
        $query = "UPDATE mission SET sub_title = '$edit_title',description = '$edit_description' WHERE id='$id'";
        $query_run = mysqli_query($connection, $query);

        if ($query_run) 
        {
            $_SESSION['success'] = "mission statement Updated Successfully";
            header('location:mission.php');
        }
        else 
        {
            $_SESSION['status'] = "mission statement Not Updated";
            header('location:mission.php');
        }
    }

}

//VISION MISSION

if (isset($_POST['delete_mission_btn'])) 
{
    $id = $_POST['delete_mission_id'];
    
    $query = "DELETE FROM mission WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if ($query_run) 
    {
        $_SESSION['success'] = "mission statement Is Deleted Successfully";
        header('location:mission.php');
    }
    else 
    {
        $_SESSION['status'] = "mission statement Is Not Deleted ";
        header('location:mission.php');
    }
}


?>
