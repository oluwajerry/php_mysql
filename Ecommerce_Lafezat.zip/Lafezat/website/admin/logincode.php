<?php
include('security.php'); 

$connection = mysqli_connect("localhost","root","","adminpanel");

//LOGIN 

if (isset($_POST['login_btn'])) 
{
    $email_login = $_POST['email'];
    $password_login = md5($_POST['password']);
    
    $query = "SELECT * FROM register WHERE email = '$email_login' AND password = '$password_login' ";
    $query_run = mysqli_query($connection, $query);
    $usertypes = mysqli_fetch_array($query_run);

    if ($usertypes['usertype'] == "admin") 
    {
        $_SESSION['username'] = $usertypes['firstname'] ;
        $_SESSION['adminID'] = $usertypes['id'] ;
        header('location:index.php');
    }
    else if ($usertypes['usertype'] == "user") 
    {
        $_SESSION['user_name'] = $usertypes['firstname'] ;
        $_SESSION['userID'] = $usertypes['id'] ;
        header('location: ../index.php');
    }
    else
    {
        $_SESSION['status'] = "Email or Password is invalid";
        header('location:login.php');
    }

}

?>