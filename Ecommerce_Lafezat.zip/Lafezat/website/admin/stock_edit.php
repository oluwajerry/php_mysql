<?php 
   include('security.php'); 
    include('includes/header.php'); 
    include('includes/navbar.php');
?>

<div class="container-fluid">

    <!-- DataTable Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 fw-bold text-primary">Edit Stock Item</h6>
        </div>
        <div class="card-body">
        <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['editstock_btn'])) 
                {
                    $id = $_POST['editstock_id'];
                    
                    $query = "SELECT * FROM stock WHERE stock_id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
            <form action="code.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="edit_stock_id" value="<?php echo $row['stock_id']; ?>">
                <?php
                    }
                }
                ?>
                <div class="form-group">
                    <label>select item name</label>
                        <select name="item_name" class="form-control">  
                            <?php
                            
                             $connection = mysqli_connect("localhost", "root", "", "adminpanel");
                            $query = "SELECT * FROM item_table";
                            $query_run = mysqli_query($connection,$query);

                            
                                if (mysqli_num_rows($query_run) > 0 ) 
                                {
                                    foreach ($query_run as $row) 
                                    {
                                        ?>
                                        <option value="<?= $row['item_id']?>"><?= $row['item_name']?></option>
                                        <?php
                                    }
                                }
                                else 
                                { 
                                    ?>
                                     <option value="">no option</option> 
                                    <?php
                                }
                                ?>
                        </select>
                </div>
                <?php
                //RETRIEVE AND EDIT
                $connection = mysqli_connect("localhost","root","","adminpanel");
                if (isset($_POST['editstock_btn'])) 
                {
                    $id = $_POST['editstock_id'];
                    
                    $query = "SELECT * FROM stock WHERE stock_id='$id' ";
                    $query_run = mysqli_query($connection, $query);
                    foreach ($query_run as $row) 
                    {
                       ?>
                <div class="form-group">
                    <label for="">price</label>
                    <input type="number" name="edit_price" value="<?php echo $row['price']; ?>" class="form-control" placeholder="Enter price">
                </div>
                <div class="form-group">
                    <label for="">cost</label>
                    <input type="number" name="edit_cost" value="<?php echo $row['cost']; ?>" class="form-control" placeholder="Enter cost">
                </div>
                <div class="form-group">
                    <label for="">image</label>
                    <input type="file" name="edit_image" value="<?php echo $row['image']; ?>" class="form-control" placeholder="Enter image">
                </div>
                <div class="form-group">
                    <label for="">stock quantity</label>
                    <input type="text" name="edit_stock_qty" value="<?php echo $row['stock_qty']; ?>" class="form-control" placeholder="Enter brand">
                </div>
                <a href="stock.php" class="btn btn-danger"> CANCEL</a>
                <button type="submit" name="update_stock_btn" class="btn btn-primary">UPDATE</button>
            </form>

            <?php
                    }
                }
            ?>
        </div>
    </div>

</div




<?php 
    include('includes/scripts.php'); 
    include('includes/footer.php');
?>