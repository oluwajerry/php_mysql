<?php 
include('include/session.php');

 if (isset($_SESSION['userID'])) 
{  
    
    include('function.php');
    include('include/header.php'); 
    include('include/navbar.php');
    

    $cart_id = $_POST['cart_id'];
    $qty = $_POST['Qty'];

    $_SESSION['products'] = array();
    for ($i = 0; $i < count($cart_id); $i++) 
    {
        $_SESSION['products'][$cart_id[$i]] = $qty[$i];
    }
    //echo implode($_SESSION['products']);
?>

        <div class="container">
            <div class="combine">
                <div class="row">
                    <div class="col-md-7">
                        <div class="shadow bg-white p-3">
                                <h3 class="text">
                                CHECKOUT
                                </h3>
                                <hr>

                                <form action="payment.php"  method="POST">
                                    <div class="row">
                                        <?php
                                              
                                                $connection = mysqli_connect("localhost","root","","adminpanel");

                                                $sql = "SELECT * FROM register WHERE id=$_SESSION[userID]";
                                                $result=mysqli_query($connection, $sql);
                                                while ( $row =mysqli_fetch_assoc($result) )
                                                {
                                        
                                                    $_SESSION['firstname']=$row['firstname'];
                                                    $_SESSION['lastname']=$row['lastname'];
                                                    $_SESSION['gmail']=$row['email'];
                                                    
                                                }
                                                
                                        ?>


            <!--<form id="paymentForm">
  <div class="form-group">
    <label for="email">Email Address</label>
    <input type="email" id="email-address" required />
  </div>
  <div class="form-group">
    <label for="amount">Amount</label>
    <input type="tel" id="amount" required />
  </div>
  <div class="form-group">
    <label for="first-name">First Name</label>
    <input type="text" id="first-name" />
  </div>
  <div class="form-group">
    <label for="last-name">Last Name</label>
    <input type="text" id="last-name" />
  </div>
  <div class="form-submit">
    <button type="submit" onclick="payWithPaystack()"> Pay </button>
  </div>
</form>

<script src="https://js.paystack.co/v1/inline.js"></script> --> 



                                        <div class="col-md-6 mb-3">
                                            <label class="text fw-bolder">First Name</label>
                                            <input type="text" id="first-name" name="firstname" class="form-control" value="<?php echo $_SESSION['firstname']; ?>" required/>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="text fw-bolder">Last Name</label>
                                            <input type="text" name="lastname" id="last-name" class="form-control"  value="<?php echo  $_SESSION['lastname'] ; ?> " required />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="text fw-bolder">Phone number</label>
                                            <input type="number" name="phone" class="form-control"  required />
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="text fw-bolder">Email Address</label>
                                            <input type="email" id="email-address" name="email" class="form-control" value="<?php echo $_SESSION['gmail']?>" required />
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label class="text fw-bolder">Pin-code (Zip-code)</label>
                                            <input type="number" name="pincode" class="form-control" placeholder="Enter Pin-code" required/>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label class="text fw-bolder">Full Delivery Address</label>
                                            <textarea name="address" class="form-control" rows="2" required></textarea>
                                        </div>
                                        <div class="col-md-12 mb-3 required">
                                            <label class="text fw-bolder">State/Region</label>
                                            <select class="form-select" aria-label="Default select example" name = "city" required>Select state<br>
                                                <option value="Abuja">Abuja</option>
                                                <option value="Lagos">Lagos</option>
                                                <option value="Ibadan">Ibadan</option>
                                                <option value="Enugu">Enugu</option>
                                                <option value="River">River</option>
                                            </select>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label class="text fw-bolder">City</label>
                                            <select class="form-select" aria-label="Default select example" name = "citty" required>Select city<br>
                                                <option value="Abuja">Abuja</option>
                                                <option value="Lagos">Lagos</option>
                                                <option value="Ibadan">Ibadan</option>
                                                <option value="Enugu">Enugu</option>
                                                <option value="River">River</option>
                                            </select>
                                        </div>
                                        <div class="col-md-12 mb-3 ">
                                            <input type="submit" value="PLACE ORDER " class="btn btn-warning w-100 fw-bolder ">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <!-- Amount -->
                                            <input type="hidden" id="amount" name="amount" class="form-control"  required />
                                        </div>
                                    </div>
                                </form>
                        </div>
                    </div>
                    
                    <div class=" col-md-5"> 
                        <?php displayCartItems(); ?>
                    </div>
                </div>
            </div>
        </div>

<?php 
    include('include/script.php'); 
    include('include/footer.php');
 }
else 
{
    echo"<script>alert('please login to access the checkout page ')</script>";
    echo"<script>window.location='admin/login.php'</script>"; 
    //header('location:admin/login.php');    
} 
?>