<?php
//session_start();
//create connection
function con(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db_name = "adminpanel";

    // Create connection
    $mysqli = mysqli_connect($servername, $username, $password, $db_name); 
    // Check connection
    if ($mysqli->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }else {
        return $mysqli;
    }
}

// select item from database
function getData(){
    
    //sql query statement
    $sql = "SELECT item_table.item_name,stock.image,item_table.brand_name,stock.price,item_table.item_id 
        FROM item_table
        INNER JOIN stock
        ON item_table.item_id = stock.item_id
        GROUP BY item_table.item_id";


    $result=mysqli_query(con(), $sql);

    if (mysqli_num_rows($result) > 0) {
        return $result;
    }
}


function displayItems($item_id,$image,$brand_name,$item_name,$price){
    $item = "
                <div class=\"col-sm-6 col-md-3 col-lg-3 mb-5\">
                    <form action=\"shop.php\" method=\"POST\">
                    <div class=\"card shadow\">
                        <div class=\"product\">
                        <label class=\"store\" style=\"position: absolute;
                            background-color:navy;
                            color: #fff;
                            border-radius: 4px;
                            padding: 2px 12px;
                            margin: 8px;
                            font-size: 12px;\">
                            In Store
                        </label>
                        <img src=\"admin/upload/$image\" alt=\"image\" class=\"img-fluid card-img-top\" style=\"object-fit: cover; height: 200px; \">
                        </div>
                        <div class=\"card-body d-flex flex-column justify-content-between\">
                        <div>
                            <p class=\"product-brand\" style=\"font-size: 14px;
                            font-weight: 400;
                            margin-bottom: 4px;
                            color: #937979;
                            white-space: nowrap;
                            text-overflow: ellipsis;
                            overflow: hidden;\">
                                $brand_name
                            </p>
                            <h5 class=\"card-title\">$item_name</h5>
                            <h5>
                            <span class=\"price\">₦$price</span>
                            </h5>
                        </div>
                        <div class=\"text-center\">
                            <button type=\"submit\" class=\"btn btn-warning my-2\" id=\"tick-button\" name=\"add\">Add to Cart <i class=\"fas fa-shopping-cart\"></i></button>
                            <input type=\"hidden\" name=\"item_id\" value=\"$item_id\">
                        </div>
                        </div>
                    </div>
                    </form>
                </div>
            ";



    echo $item;
}



function cartItem($image,$item_name,$price,$quanty,$id,$count){
    $displayItem = "
        <div class=\"pb-3 \">
            <div class=\"text fw-bolder\">ORDER SUMMARY</div>
            <div class=\"\" >
                <div><h6>YOUR ORDER($count items; )</h6></div>  
                <div class=\"col-md-4 pl-0 \">
                    <img src=\"admin/upload/$image\" alt=\"bluetooth\" class=\"img-fluid\"><span>$item_name<br> ₦$price<br>Qty:$quanty[$id]</span>
                </div>
                <div>
                    Subtotal: <span class=\"justify-content-end text subtotal\">";
                    $subtotal = ($price)*($quanty[$id]);
                    
    $displayItem2 =  "
            $subtotal
                    </span>
                </div>
            </div>
            <div class=\"cart\">
                <button  class=\"w-100 btn btn-warning\"><a href=\"cart.php\" class=\"fw-bolder text text-decoration-none\">MODIFY CART</a></button>
            </div>
        </div>
            ";
    echo $displayItem; echo $displayItem2; 
    

}


 function displayCartItems()
 {
    
    if (isset($_SESSION['cart'])) 
    {
        $item_id=array_column($_SESSION['cart'], 'item_id'); 
        $connection = mysqli_connect("localhost","root","","adminpanel");

        $sql = "SELECT item_table.item_name,stock.image,item_table.brand_name,stock.price,item_table.item_id 
        FROM item_table
        INNER JOIN stock
        ON item_table.item_id = stock.item_id
        GROUP BY item_table.item_id";
        
        $result=mysqli_query($connection, $sql);
        while ( $row =mysqli_fetch_assoc($result) )
        {
            foreach ($_SESSION['products'] as $id => $quantity) 
            {
                if ($row['item_id']==$id)
                {

                    $count=(count($_SESSION['cart']));

                    cartItem($row['image'],$row['item_name'],$row['price'],$_SESSION['products'],$id,$count);
                }

            }
        }
    }   


 }




?>