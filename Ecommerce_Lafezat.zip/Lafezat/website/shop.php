<?php

include('include/session.php');
// include some external script
include 'function.php';

// add item to cart on button clicked
      if (isset($_POST['add']))
      {

          if (isset($_SESSION['cart'])) 
          {
            
              $item_array_id = array_column($_SESSION['cart'],"item_id"); 
            

              if (in_array($_POST['item_id'],$item_array_id )) 
              {
                  echo"<script>alert('product is already added in the cart')</script>";
                  echo"<script>window.location='session.php'</script>"; 
                  
              }
              else 
              {
                  $count= count($_SESSION['cart']);
                  $item_array = array(
                      'item_id'=> $_POST['item_id'] 
                  );
                  
                $_SESSION['cart'][$count]=$item_array;
              }
          }
          else 
          {
              $item_array = array(
                  'item_id'=> $_POST['item_id']
                  
              );

              $_SESSION['cart'][0]= $item_array;
             
          }   
      }
    //echo implode(array_column($_SESSION['cart'],"item_id"));
?>

<?php 
    include('include/header.php'); 
    include('include/navbar.php');
?>
  <section>
    
    <div class="py-3 py-md-5 bg-light">
      <div class="container">
        <div class="row">
          <div class="col-12 col-md-12">
            <div class=" text-center text-warning h2 fw-bolder mb-5 name">
              Enjoy a nice Shopping Experience !!!
            </div>
          </div> 
                                 
          <?php
            $result= getData();
                                
            while ($row = mysqli_fetch_assoc($result)) 
            {
              displayItems($row['item_id'],$row['image'], $row['brand_name'], $row['item_name'],$row['price']);
            }
          ?>
          <?php
              /* // set variable to true
              $isClicked = true;

              // return JSON response
              header('Content-Type: application/json');
              echo json_encode(array('isClicked' => $isClicked)); */
          ?>
        </div>
      </div>
    </div>

  </section>








  <?php 
    include('include/script.php'); 
    include('include/footer.php');
?>